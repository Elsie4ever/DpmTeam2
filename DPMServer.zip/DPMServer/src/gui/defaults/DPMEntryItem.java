package gui.defaults;

import java.awt.*;

public class DPMEntryItem {
	
	public String key;
	public TextField entry;
	
	public DPMEntryItem(String key, TextField entry){
		this.key = key;
		this.entry = entry;
	}

}
