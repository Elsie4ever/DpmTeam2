package gui.defaults;

import java.awt.*;
import gui.*;

@SuppressWarnings("serial")
public class DPMPanel extends Panel {
	protected MainWindow mw;
	
	public DPMPanel(MainWindow mw) {
		this.mw = mw;
	}
}
