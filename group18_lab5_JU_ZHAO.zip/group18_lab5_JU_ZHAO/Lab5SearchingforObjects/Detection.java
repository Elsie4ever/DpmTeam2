package Lab5SearchingforObjects;

import java.lang.reflect.Array;
import java.util.*;
import lejos.hardware.*;
import lejos.hardware.motor.EV3LargeRegulatedMotor;
import lejos.robotics.SampleProvider;
import lejos.utility.Delay;
import lejos.hardware.lcd.TextLCD;
import lejos.hardware.ev3.LocalEV3;
import lejos.hardware.Sound;

public class Detection {
	private Odometer odo;
	private Navigation navi;
	private SampleProvider colorSensor;
	private SampleProvider usSensor;
	private EV3LargeRegulatedMotor leftMotor, rightMotor, sensorMotor, armMotor;
	private final int motorStraight = 100, FILTER_OUT = 20, sensorRotate = 50, sensorSpeed = 30;
	private int errorFilter, errorFilterMax, distanceMax, wallDistance;

	private float[] colorData, usData;
	private double d11, d12, d13, theta11, theta12, theta13, angleA, blockWidth;
	private double boardY = 90, boardX = 90;
	private int fallingEdgeCount = 0, risingEdgeCount = 0, delay = 40;
	final TextLCD t = LocalEV3.get().getTextLCD();
	private boolean isBlock, foundObject;
	float color;

	//constructor for detection mechanism
	public Detection(Odometer odo, SampleProvider usSensor, float[] usData, EV3LargeRegulatedMotor sensorMotor,
			SampleProvider colorSensor, float[] colorData, EV3LargeRegulatedMotor armMotor) {
		this.odo = odo;
		this.usSensor = usSensor;
		this.usData = usData;
		this.colorSensor = colorSensor;
		this.colorData = colorData;
		this.sensorMotor = sensorMotor;
		this.usSensor = usSensor;
		this.usData = usData;
		this.armMotor=armMotor;
		errorFilter = 0;
		errorFilterMax = 20;
		distanceMax = 100;
		wallDistance = 30;
		navi = new Navigation(odo);
	}

	public boolean detectPart1() { 
		double distance;
		while (true) {
			distance = this.getFilteredData();//get current distance from ultrasonic sensor											 
			if (distance < 5) {	//if the distance is smaller than 5, start detcting																		 
				t.drawString("OBJECT DETECTED", 0, 5);	//show that object is being detected							 

				while (distance < 5) {	//when the distance is smaller than 5											 
				color = getColor();	//get color from light sensor																	 
				
				isBlock = ( colorData[2] > 0.058);//if the block is styrofoam, set boolean to true																 

				if (isBlock){	//print "Block" if the block is styrofoam																				 
					Sound.beep();									
					t.drawString("BLOCK", 5, 6);
				}else{   //print "not Block" if the block is wooden block
					Sound.twoBeeps();               
					t.drawString("NOT BLOCK", 5, 6);
				}
				Delay.msDelay(1000);
				t.clear();
				return isBlock;
			}
				}}
		
		}
		
	public boolean objectDetection() { 
		double distance;
		while (true) {
			distance = this.getFilteredData();//get current distance from ultrasonic sensor											 
			if (distance < 5) {	//if the distance is smaller than 5, start detcting																		 
				t.drawString("OBJECT DETECTED", 0, 5);	//show that object is being detected							 

				while (distance < 5) {	//when the distance is smaller than 5											 
				color = getColor();	//get color from light sensor																	 
				
				isBlock = ( colorData[2] > 0.058);//if the block is styrofoam, set boolean to true																 

				if (isBlock){	//print "Block" if the block is styrofoam																				 
					Sound.beep();									
					t.drawString("BLOCK", 5, 6);
				}else{   //print "not Block" if the block is wooden block
					Sound.twoBeeps();
					t.drawString("NOT BLOCK", 5, 6);
				}
				Delay.msDelay(1000);
				t.clear();
				return isBlock;
			}
				}}
	}

	public void findObjects() {									//let A be the straight path in front of the robot when it is facing 90deg
																															//let B be the straight path in front of the robot when it is facing 0deg																													// check A and B for empty lanes
		navi.turnTo(90, true);
		Delay.msDelay(100);
		boolean a = isEmpty(getFilteredData(), odo);
		navi.turnTo(0, true);
		Delay.msDelay(100);
		boolean b = isEmpty(getFilteredData(), odo);

		if(!a && !b){														 //if both A and B are blocked, check both
			check(odo.getX(), odo.getY(), 90);
		}else if(a ^ b){												   //if ONLY 1 of the two path is blocked, go check the blocked lane
			if(a){ check(odo.getX(), odo.getY(), 0); }
			else{ check(odo.getX(), odo.getY(), 90); }
		}else{																										 //if both are empty, check A first, then check B
			checkSep(odo.getX(), odo.getY(), 90, false);
			checkSep(odo.getX(), odo.getY(), 0, false);
		}
	}

	private int sensorFacing(double robotFacing){//is the robot is facing toward, the sensor should face right
		if (robotFacing < 225 && robotFacing >= 45){
			return 75;
		}else{//if the robot is facing right, the sensor should be facing toward
			return -75;
		}
	}

	private boolean isEmpty(double distance, Odometer odo){	//check if the path that the sensor is facing is empty
		if(odo.getAng()<255 && odo.getAng() >= 45){	//when robot is facing toward
			if(distance< 80-odo.getX()){ 
				return false;
			}
			t.drawString("empty", 10, 1);
			return true;
		} else { //when robot is facing right
			if(distance< 80-odo.getY()){ 
				return false; 
			}
			t.drawString("empty", 10, 1);
			return true;
		}
	}

	private void check(double x, double y, double heading){					
		boolean isBlock = false;//the bloc kis not found																								 
		sensorMotor.setSpeed(sensorSpeed);
		sensorMotor.rotateTo(20, false);//let sensor face toward
		navi.turnTo(heading, true);	//turn to the desired heading
		while(true){
			Sound.twoBeeps();
			if(!isEmpty(getFilteredData(), odo)){//if current path is not empty
				navi.setSpeeds(motorStraight, motorStraight);//keep going 
				if(getFilteredData() < 5){//if the robot is close to the object
					Sound.beep();
					leftMotor.stop();
					rightMotor.stop();
					isBlock = objectDetection();//detect object 
					break;
				}
			}else{//if current path is empty
				navi.setSpeeds(0, 0);			
				sensorMotor.setSpeed(30);//rotate the sensor to find object
				sensorMotor.rotate(-15);
				sensorMotor.rotate(15);
				while(isEmpty(getFilteredData(), odo) && sensorMotor.isMoving()){   //keep looking for the object
					t.drawString("scanning", 10, 3);
				}
				sensorMotor.setSpeed(0);//stop the motor when object is found
				check(odo.getX(), odo.getY(), odo.getAng()-sensorMotor.getPosition());  //check it
				break;
			}
		}
		if (!isBlock){//if the object is not the block
			navi.turnTo(heading, true);																						
			sensorMotor.setSpeed(sensorSpeed);
			sensorMotor.rotateTo(sensorFacing(odo.getAng()), false);//turn right the sensor if the robot is facing forward
            double tempX = odo.getX();
            double tempY = odo.getY();
			navi.travelToReverse(x, y);	// move back to the previous position 
			
			while(navi.isTraveling()){// during the robot going reversly
				if (!isEmpty(getFilteredData(), odo)){// if some object is detected
					navi.setSpeeds(0,0);																							  
					check(odo.getX(), odo.getY(), ((360+odo.getAng()-sensorMotor.getPosition())%360));  //check 
				}
			}
            navi.travelTo(tempX, tempY);																			
            checkSep(odo.getX(), odo.getY(), 90 - heading, true);						 
            //turn the robot in order to face the sensor in the opposite direction    //  check the upper area																																	            																																	           																													
            int upperX = 70;
            int upperY = 70;
            
            if(75 < odo.getAng() && odo.getAng() <105 ) upperY=(int)odo.getY();
            else if(odo.getAng()<15 || odo.getAng() >345) upperX = (int)odo.getX();

            navi.travelTo(upperX,upperY);//travel to the upper coner x&y		
            sensorMotor.setSpeed(50);																					
            int tempDeg = ( (360+(int) ( odo.getAng()- sensorMotor.getPosition() )) %360);
            
            sensorMotor.setSpeed(sensorSpeed);//rotate sensor toward
            sensorMotor.rotateTo(0, false);
            navi.turnTo(tempDeg, true);	//rotate to the undected direction
            
            float Dis = getFilteredData();
            t.drawString("Dis "+(int)getFilteredData(), 0, 5);
         
            while(true){																										 
            	t.drawString("Dis "+(int)getFilteredData(), 0, 5);
    					if(getFilteredData() < 70){
    				
	    				navi.setSpeeds(motorStraight, motorStraight);
	    				if(getFilteredData() < 5){																			 
	    					isBlock = objectDetection();//check 
	    					break;
	    				}
	    			  }else{//searching for object																			
		    				navi.setSpeeds(0, 0);
		    				sensorMotor.setSpeed(30);
		    				sensorMotor.rotateTo(-15, false);
		    				sensorMotor.rotateTo(15, true);
		    				while(isEmpty(getFilteredData(), odo) && sensorMotor.isMoving()){
		    					t.drawString("scanning", 10, 3);
		    				}
		    				sensorMotor.setSpeed(0);
		    				check(odo.getX(), odo.getY(), odo.getAng()-sensorMotor.getPosition());
		    				break;
	    				}
    				}
            while(Dis > 5){//move forward until the distance is smaller than 5
            	navi.setSpeeds(motorStraight, motorStraight);
            	Dis = getFilteredData();
            	
            }
            //check the object
            navi.setSpeeds(0, 0);
            boolean isSecondBlock = objectDetection();
            if(isSecondBlock){ 
            	getBlock();
            	navi.travelTo(72, 72);//if it is styrofoam, take it and go to top left corner
            	Sound.beep();
    			Sound.twoBeeps();
    			System.exit(0);
            }
            return;

		}
		else{
			//isBlock returns true when it is styrofoam. take it and go to final destination
			getBlock();
        	navi.travelTo(72, 72);
			Sound.beep();
			Sound.twoBeeps();
        	System.exit(0);
			return;
		}
		 
	}

	private void getBlock(){
		armMotor.rotate(160);
	}
	

	
    //check the path that is not empty
	private void checkSep(double x, double y, double heading, boolean isSection3Empty){			
		double tempX = x;
		double tempY = y;
		navi.setSpeeds(0, 0);
		navi.turnTo(heading, true);
		sensorMotor.rotateTo(sensorFacing(odo.getAng()));//  sensor turns to 90 degree of path
		navi.setSpeeds(motorStraight, motorStraight);
		while(true){
        	if(isEmpty(getFilteredData(), odo)){    //as it sees nothing, breaking the loop
        		break;
        	}else{           //as it sees nothing, keep going
        		t.drawString("still wood", 10, 2);
        	}
        }
		while(odo.getX() < boardX - 15 && odo.getY() < boardY - 15){//limits the robot from driving too far while seeing nothing
			if (!isEmpty(getFilteredData(), odo)){
				tempX = odo.getX();
				tempY = odo.getY();
				check(tempX, tempY, ((360+odo.getAng() - sensorMotor.getPosition())%360));//if it sees something as it's scanning, then go check it
			}
		}
		navi.setSpeeds(0, 0);
		if(isSection3Empty) { return; }
		navi.travelToReverse(x, y);
	}

	
	private float getFilteredData() {
		usSensor.fetchSample(usData, 0); //get current distances from sensor 

																																												
		if (usData[0] * 100 > distanceMax && errorFilter < errorFilterMax) {
			errorFilter++;
			return (distanceMax - 1);
		}

		// set the maximum distace
		else if (usData[0] * 100 > distanceMax && errorFilter >= errorFilterMax) {
			return usData[0] * 100;
		}

																																												
		else {
			float distance = usData[0] * 100;
			if (distance > distanceMax) {
				distance = distanceMax;
			}
			if (distance == 0) {
			 
			}
			errorFilter = 0;
			return distance;
		}
	}

	//get light sensor data 
	private float getColor() {
		colorSensor.fetchSample(colorData, 0);
		float data = colorData[2];
		usSensor.fetchSample (usData, 0);
		float distance = (int)(usData[0]*100.0);
		
		return data;
	}
}