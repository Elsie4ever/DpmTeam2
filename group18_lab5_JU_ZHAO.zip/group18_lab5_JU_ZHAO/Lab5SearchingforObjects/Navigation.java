package Lab5SearchingforObjects;

import lejos.hardware.motor.EV3LargeRegulatedMotor;

public class Navigation {
	//state variables
	final static int speedHigh = 200, speedLow = 100, ACCELERATION = 1100, turnSpeed = 50;
	final static double degTol = 1.0, radius = 2.1;
	public static final double TRACK = 15.7;
	private Odometer odometer;
	private EV3LargeRegulatedMotor leftMotor, rightMotor;

	public Navigation(Odometer odo) {
		this.odometer = odo;

		EV3LargeRegulatedMotor[] motors = this.odometer.getMotors();
		this.leftMotor = motors[0];
		this.rightMotor = motors[1];

		// set acceleration
		this.leftMotor.setAcceleration(ACCELERATION);
		this.rightMotor.setAcceleration(ACCELERATION);
	}

	//this method is to set two motor speed at same time
	public void setSpeeds(float leftSpeed, float rightSpeed) {
		this.leftMotor.setSpeed(leftSpeed);
		this.rightMotor.setSpeed(rightSpeed);
		if (leftSpeed < 0)
			this.leftMotor.backward();
		else
			this.leftMotor.forward();
		if (rightSpeed < 0)
			this.rightMotor.backward();
		else
			this.rightMotor.forward();
	}

	//set two motors in float mode
	public void setFloat() {
		this.leftMotor.stop();
		this.rightMotor.stop();
		this.leftMotor.flt(true);
		this.rightMotor.flt(true);
	}																																														 
	//travel to a position																																														 
	public void travelTo(double xLast, double yLast) {
		double x=this.odometer.getX();																													   
		double y=this.odometer.getY();
		double deltaX = xLast - x; 																															 
		double deltaY = yLast - y;
		
		double newDeg, distance;
        //calculate the angle for robot to turn
		newDeg = calculateNewDegree(xLast,yLast,deltaX,deltaY); 																 
		this.turnTo(newDeg*180.0/Math.PI, true);																									 
		//calculate the distance difference from current position to final position																																													 
		distance = Math.sqrt(deltaX*deltaX + deltaY*deltaY); 																			 

		leftMotor.setSpeed(speedLow);
		rightMotor.setSpeed(speedLow);
		//turn the motor in degrees by calculating (distance difference/2*pi*radius)*360 
		leftMotor.rotate(convertDistance(radius, distance), true); 																 
		rightMotor.rotate(convertDistance(radius, distance), false); 															 
																		   																												 
		}
	//travel reversly, similar to "travelTo" method 
	public void travelToReverse(double xLast, double yLast) {
		double x=this.odometer.getX(); 																														 
		double y=this.odometer.getY();
		double deltaX = xLast - x; 																															 
		double deltaY = yLast - y;
		
		double newDeg, newDegReverse, distance;

		newDeg = calculateNewDegree(xLast,yLast,deltaX,deltaY); 																 
		newDegReverse = (newDeg+Math.PI)%(2*Math.PI);
		this.turnTo(newDegReverse*180.0/Math.PI, true);																				    
																																															 
		distance = Math.sqrt(deltaX*deltaX + deltaY*deltaY); 																			 

		leftMotor.setSpeed(speedLow);
		rightMotor.setSpeed(speedLow);
		leftMotor.rotate(-convertDistance(radius, distance), true); 															 
		rightMotor.rotate(-convertDistance(radius, distance), true); 															 
																		   																												 
		}
        //if left or right motor is moving, return true
		public boolean isTraveling(){
			if (leftMotor.isMoving() || rightMotor.isMoving()){return true;}
			else{return false;}
		}
   //let robot to rotate
	public void turnTo(double angle, boolean stop) {

		if((angle < 90 && this.odometer.getAng() > 270) || (angle > 270 && this.odometer.getAng() < 90)){   
			if(angle < 90){																																								   /*turning through 0 degrees*/
				angle+=360;
			}
			else{
				angle=360-angle;
			}
		}
		
		double error = angle - this.odometer.getAng();
		
		while (Math.abs(error) > degTol) {

			if((angle < 90 && this.odometer.getAng() > 270) || (angle > 270 && this.odometer.getAng() < 90)){
				if(angle < 90){
					angle+=360;
				}
				else{
					angle=360-angle;
				}
			}
			
			error = angle - this.odometer.getAng();

			if (error < -180.0) {
				this.setSpeeds(-turnSpeed, turnSpeed);
			} else if (error < 0.0) {
				this.setSpeeds(turnSpeed, -turnSpeed);
			} else if (error > 180.0) {
				this.setSpeeds(turnSpeed, -turnSpeed);
			} else {
				this.setSpeeds(-turnSpeed, turnSpeed);
			}
		}

		if (stop) {
			this.setSpeeds(0, 0);
		}
	}
	// converts rotations of robot to the required angle rotation of wheel
	public int convertAngle(double radius, double width, double angle) { 																	 
		return convertDistance(radius, Math.PI * width * angle / (2 * Math.PI)); 														 
																																																				 
	}
    //convert distance to angle
	public int convertDistance(double radius, double distance) { 																					 
		return (int) ((180.0 * distance) / (Math.PI * radius));
	}
	
	/* Based on current and final positions, what is the absolute angle of the final position*/																																																			
	public double calculateNewDegree(double x, double y, double dx, double dy){ 
		if (dx >= 0) {
			if (dy >= 0) {
				return Math.atan(Math.abs(dy) / Math.abs(dx));
			} else {
				return Math.PI*2 - Math.atan(Math.abs(dy) / Math.abs(dx));
			}
		} else {
			if (dy >= 0) {
				return Math.PI - Math.atan(Math.abs(dy) / Math.abs(dx));
			} else {
				return Math.PI + Math.atan(Math.abs(dy) / Math.abs(dx));
			}
		}
	}

	/*
	 * Go foward a set distance in cm
	 */
	public void goForward(double distance) {
		leftMotor.rotate(convertDistance(radius, distance), true); 
		rightMotor.rotate(convertDistance(radius, distance), false);
	}
}
