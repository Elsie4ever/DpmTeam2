package wallFollower;
import lejos.hardware.motor.EV3LargeRegulatedMotor;
import wallFollower.UltrasonicController;

public class PController implements UltrasonicController {
	
	private final int FILTER_OUT = 20;
	private final int FILTER_DISTANCE = 70;
	private final int MAX_SENSOR = 255;
	private final int INITIAL_SPEED = 120;
	private final double PROP_SCALE = 1.5;

	// passed variables
	private final int bandCenter, bandwidth;
	private EV3LargeRegulatedMotor leftMotor, rightMotor;
	
	private int distance;
	private int filterControl;
	private int error = 0;
	
	// Default Constructor
	public PController(EV3LargeRegulatedMotor leftMotor, EV3LargeRegulatedMotor rightMotor,
					   int bandCenter, int bandwidth) {
		
		this.bandCenter = bandCenter;
		this.bandwidth = bandwidth;
		this.leftMotor = leftMotor;
		this.rightMotor = rightMotor;
		this.filterControl = 0;

		// Go!
		leftMotor.setSpeed(INITIAL_SPEED);
		rightMotor.setSpeed(INITIAL_SPEED);
		leftMotor.forward();
		rightMotor.forward();
	}
	
	@Override
	public void processUSData(int sensorDistance) {		


		// if sensor meet sharp corners or big gaps, filter will be delayed
		if (sensorDistance >= FILTER_DISTANCE && this.filterControl < FILTER_OUT) {
			// bad value, do not set the sensorDistance var, however do increment the filter value
			this.filterControl ++;
		} else if (sensorDistance >= FILTER_DISTANCE){
			// set sensorDistance to 255
			this.filterControl = 0;
			this.distance = MAX_SENSOR;
		} else {
			// sensorDistance went below FILTER_DISTANCE, reset everything.
			this.filterControl = 0;
			this.distance = sensorDistance;
		}

		// Calculate difference between bandcenter and measured distance
		error = bandCenter - this.distance;
		
		// Compute the correction speeds of motor(variableRate)
		int variableRate = (int) (Math.abs(error) * PROP_SCALE);
		
		// Go straight
		if (Math.abs(error) <= bandwidth) {
			leftMotor.setSpeed(INITIAL_SPEED * 2);
			rightMotor.setSpeed(INITIAL_SPEED * 2);
			leftMotor.forward();
			rightMotor.forward();				
		}
		
		// if too close to wall, turn right
		else if (error > 0) {
			
			// RIGHT_SCALE accounts for distError being disproportional from one side to the other side of the bandCenter
			leftMotor.setSpeed(INITIAL_SPEED + variableRate*4);
			rightMotor.setSpeed(INITIAL_SPEED - variableRate*4);
			leftMotor.forward();
			rightMotor.forward();	
		}
		
		// if too far from wall, turn left
		else if (this.distance>bandCenter+bandwidth) {
			
			leftMotor.setSpeed(INITIAL_SPEED - variableRate);
			rightMotor.setSpeed(INITIAL_SPEED + variableRate);
			leftMotor.forward();
			rightMotor.forward();
							
		}
	}

	
	@Override
	public int readUSDistance() {
		return this.distance;
	}

}
