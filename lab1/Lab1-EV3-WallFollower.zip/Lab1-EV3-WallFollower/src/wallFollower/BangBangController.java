package wallFollower;
import lejos.hardware.motor.*;
import wallFollower.UltrasonicController;

public class BangBangController implements UltrasonicController{
	// Constants
	private int FILTER_COUNT = 30;
	private int MAX_SENSOR = 255;
	private int FILTER_DISTANCE = 75;

	// passed member constants
	private final int bandCenter, bandwidth, motorLow, motorHigh;
	private EV3LargeRegulatedMotor leftMotor, rightMotor;

	// member variables
	private int distance;
	private int error = 0;
	private int filterTimes;

	
	
	public BangBangController(EV3LargeRegulatedMotor leftMotor, EV3LargeRegulatedMotor rightMotor,
							  int bandCenter, int bandwidth, int motorLow, int motorHigh) {
		//Default Constructor
		this.bandCenter = bandCenter;
		this.bandwidth = bandwidth;
		this.motorLow = motorLow;
		this.motorHigh = motorHigh;
		this.leftMotor = leftMotor;
		this.rightMotor = rightMotor;
		//The filterTimes will be incremented when having bad values
		this.filterTimes = 0;

		// Start rolling!
		leftMotor.setSpeed(motorHigh);
		rightMotor.setSpeed(motorHigh);
		leftMotor.forward();
		rightMotor.forward();
	}
	
	/*
		- Read sensor data
		- Handle filtering incorrect values
		- Calculate error distance from the Band Center
		- Adjust motor speeds accordingly
	*/
	@Override
	public void processUSData(int sensorDistance) {		

		// if sensor meet sharp corners or big gaps, filter will be delayed
		if (sensorDistance >= FILTER_DISTANCE && this.filterTimes < FILTER_COUNT) {
			
			// when sensor has non-ideal value, do not set the distance of sensor right away, filter value increte by one first
			this.filterTimes ++;

		} else if (sensorDistance >= FILTER_DISTANCE){
			
			this.filterTimes = 0;				// reset the counter
			this.distance = MAX_SENSOR;		// when sensor distance is more than 255, set distance to 255 

		} else {

			// distance is smaller than 255, therefore reset everything.
			this.filterTimes = 0;
			this.distance = sensorDistance;

		}
		
		// Calculate the distance Error from the bandCenter
		error = bandCenter - this.distance;
		
		// Travel straight
		if (Math.abs(error) <= bandwidth) {
			leftMotor.setSpeed(motorHigh);
			rightMotor.setSpeed(motorHigh);
			leftMotor.forward();
			rightMotor.forward();				
		}
		
		// if too close to wall, turn right
		else if (error > 0) {
			leftMotor.setSpeed(motorHigh);
			rightMotor.setSpeed(motorLow);
			leftMotor.forward();
			rightMotor.forward();	
		}
		
		// if too far from wall, turn left
		else if (error < 0) {
			leftMotor.setSpeed(motorLow);
			rightMotor.setSpeed(motorHigh);
			leftMotor.forward();
			rightMotor.forward();				
		}
	}

	@Override
	public int readUSDistance() {
		return this.distance;
	}
}
