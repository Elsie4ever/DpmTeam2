import lejos.hardware.Button;

public class Driver {


	public static void main(String[] args) {

		WifiTest1 wifi = new WifiTest1();
		wifi.run();
		int corner = wifi.getCorner();
		System.out.println(corner);
		while (Button.waitForAnyPress() != Button.ID_ESCAPE);

	}
}