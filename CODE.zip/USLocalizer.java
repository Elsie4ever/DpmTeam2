package trotty02;

import trotty02.Navigation;
import lejos.hardware.Sound;
import trotty02.UltrasonicPoller;

public class USLocalizer {
	public enum LocalizationType { FALLING_EDGE, RISING_EDGE };
	public static double ROTATION_SPEED = 30;

	private Odometer odo;
	private LocalizationType locType;
	private static final double WALL_DIST = 30;
	private Navigation simNav;
	private UltrasonicPoller usPoller;
	private static final double FRONT_SENSOR_OFFSET = 12.8;
	private static final double BACK_SENSOR_OFFSET = 3.9;
	private final double FE_OFFSET = 0; //-1*Math.PI/180;
	private final double RE_OFFSET = 0; //-3.4*Math.PI/180;
	private enum Sensor{
		FRONT, BACK
	}
	private Sensor sensor;
	
	public USLocalizer(Odometer odo, UltrasonicPoller usPoller, LocalizationType locType, Navigation simNav) {
		this.odo = odo;
		this.usPoller = usPoller;
		this.locType = locType;
		this.simNav = simNav;
	}
	
	public void doLocalization() {
		double angleA, angleB;
		double heading;
		
		//Check which sensor to sense with
		selectSensor();
		
		if (locType == LocalizationType.FALLING_EDGE){
			// rotate the robot until it sees no wall
			while(getWallDist() <= WALL_DIST){
				simNav.turnCW();
				
				if(getWallDist() > WALL_DIST){
					simNav.stopMov();
					break;
				}
			}
			
			odo.setTheta(0);
			heading = odo.getTheta(); // Remember the "heading"
			
			// keep rotating until the robot sees a wall, then latch the angle
			while(!(getWallDist() < WALL_DIST)){
				simNav.turnCW();
				
				if(getWallDist() <= WALL_DIST){
					simNav.stopMov();
					break;
				}
			}
			angleA = odo.getTheta() - heading;
			
			// switch direction and wait until it sees no wall
			while(getWallDist() <= WALL_DIST){
				simNav.turnCCW();
				
				if(getWallDist() > WALL_DIST){
					simNav.stopMov();
					break;
				}
			}
			
			// keep rotating until the robot sees a wall, then latch the angle
			while(!(getWallDist() < WALL_DIST)){
				simNav.turnCCW();
				
				if(getWallDist() <= WALL_DIST){
					simNav.stopMov();
					break;
				}
			}
			
			angleB = ((2*Math.PI - (odo.getTheta() - heading))%(2*Math.PI) + 2*Math.PI)%(2*Math.PI) + angleA;
			
			// Turn back to heading
			simNav.turnTo(heading);
			
			// calculate the actual heading
			double curHeading = (angleB - angleA) - (angleB - Math.PI/2)/2;
			
			// update the odometer position (example to follow:)
			odo.setTheta(curHeading);
			
			//Turn to the x-axis
			simNav.turnTo(0);
			
			// Mend the theta with our testing mean
			odo.setTheta(odo.getTheta() + FE_OFFSET);
		}
		
		else { // RISING_EDGE
			/*
			 * The robot should turn until it sees the wall, then look for the
			 * "rising edges:" the points where it no longer sees the wall.
			 * This is very similar to the FALLING_EDGE routine, but the robot
			 * will face toward the wall for most of it.
			 */
			
			// rotate the robot until it sees a wall
			while(getWallDist() >= WALL_DIST){
				simNav.turnCW();
				
				if(getWallDist() < WALL_DIST){
					simNav.stopMov();
					break;
				}
			}
			
			Sound.beep();
			
			odo.setTheta(0);
			heading = odo.getTheta(); // Remember the "heading"
			
			// keep rotating until the robot sees no wall, then latch the angle
			while(!(getWallDist() > WALL_DIST)){
				simNav.turnCW();
				
				if(getWallDist() >= WALL_DIST){
					simNav.stopMov();
					break;
				}
			}
			angleA = odo.getTheta() - heading;
			
			Sound.beep();Sound.beep();
			
			// switch direction and wait until it sees a wall
			while(getWallDist() >= WALL_DIST){
				simNav.turnCCW();
				
				if(getWallDist() < WALL_DIST){
					simNav.stopMov();
					break;
				}
			}
			
			Sound.beep();Sound.beep();Sound.beep();
			
			// keep rotating until the robot sees no wall, then latch the angle
			while(!(getWallDist() > WALL_DIST)){
				simNav.turnCCW();
				
				if(getWallDist() >= WALL_DIST){
					simNav.stopMov();
					break;
				}
			}
			
			Sound.beep();Sound.beep();Sound.beep();Sound.beep();
			
			angleB = ((2*Math.PI - (odo.getTheta() - heading))%(2*Math.PI) + 2*Math.PI)%(2*Math.PI) + angleA;
			
			// Turn back to heading
			simNav.turnTo(heading);
			
			// calculate the actual heading
			double curHeading = (angleB - angleA) - (Math.PI + (angleB - Math.PI/2)/2);
			
			// update the odometer position (example to follow:)
			odo.setTheta(curHeading);
			
			//Turn to the x-axis
			simNav.turnTo(0);
			
			// Mend the theta with our testing mean
			odo.setTheta(odo.getTheta() + RE_OFFSET);
		}
	}
	
	private void selectSensor(){
		if(UltrasonicPoller.getDistFront() < WALL_DIST){
			sensor = Sensor.FRONT;
			Sound.beepSequenceUp();
		}
		else if(UltrasonicPoller.getDistBack() < WALL_DIST){
			sensor = Sensor.BACK;
			Sound.beepSequence();
		}
		else{
			sensor = Sensor.BACK;
			Sound.beepSequence();
		}
	}
	
	private double getWallDist(){
		double dist;
		if(sensor == Sensor.BACK){
			dist = UltrasonicPoller.getDistBack();
		}
		else{ //sensor == Sensor.FRONT
			dist = UltrasonicPoller.getDistFront();
		}
		return dist;
	}
}
