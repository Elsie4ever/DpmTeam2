/* 
 * OdometryCorrection.java
 */
package ev3Odometer;


import java.util.*;
import lejos.hardware.sensor.EV3ColorSensor;
//import lejos.hardware.Sound;
import lejos.hardware.ev3.LocalEV3;
import lejos.robotics.Color;
import lejos.robotics.SampleProvider;
import lejos.hardware.port.Port;


public class OdometryCorrection extends Thread {
	private static final long CORRECTION_PERIOD = 10;
	//private static final double HEADING_ERROR = Math.PI / 18;		// 10 degrees
	private static final double HEADING_ERROR = 10;
	private static final double R_READING = 0.075;

	private static Odometer odometer;
	private Port colorPort = LocalEV3.get().getPort("S1");
	private EV3ColorSensor colorSensor=new EV3ColorSensor(colorPort);
	private SampleProvider colorRGBSensor = colorSensor.getRGBMode();
	private int sampleSize = colorRGBSensor.sampleSize();
	private float[] sample = new float[sampleSize];

	
	// constructor
	public OdometryCorrection(Odometer odometer) {
		this.odometer = odometer;
	}

	// run method (required for Thread)
	public void run() {
		long correctionStart, correctionEnd;

		while (true) {
			correctionStart = System.currentTimeMillis();
			int xDir, yDir;
			double heading, absAdjust, updateAmount;
			boolean[] xUpdateArr = {true, false, false};
			boolean[] yUpdateArr = {false, true, false};
			double[] updateArr = new double[3];
			// put your correction code here
			colorRGBSensor.fetchSample(sample, 0);
			//when the sensor read the black line, the value for sensor will decrease
			if(sample[0] >= R_READING){
				// initialize variables
				heading = odometer.getTheta() * (180 / Math.PI); // to degree

				xDir = 0;
				yDir = 0;
                
				if(Math.abs(heading - 0) <= HEADING_ERROR){
					yDir = 1;
					}
					else if(Math.abs(heading - HEADING_ERROR) <= 90){
					xDir = 1;
					}
					else if(Math.abs(heading - HEADING_ERROR) <= 180){
						yDir = -1;
					}
					else if(Math.abs(heading - HEADING_ERROR) <= 270){
						xDir = -1;
					}
                //when there is change on x direction
				if(xDir != 0) {
					absAdjust = current(xUpdateArr);
					
					updateArr[0] = current(xUpdateArr) ;
					//update the corrected x value
					odometer.setPosition(updateArr, xUpdateArr);
				} else {
					  //when there is change on y direction
					absAdjust = current(yUpdateArr);
		
					updateArr[1] = absAdjust;
					//update the corrected x value
					odometer.setPosition(updateArr, yUpdateArr);
				}
			}
			//when the sensor does not read the black line, the value for sensor will increase
			else if(sample[0] < R_READING) {
				// initialize variables for this loop
				heading = odometer.getTheta() * (180 / Math.PI); // to degree

				xDir = 0;
				yDir = 0;
				//Sound.beep();
				if(Math.abs(heading - 0) <= HEADING_ERROR){
					yDir = 1;
					}
					else if(Math.abs(heading - HEADING_ERROR) <= 90){
					xDir = 1;
					}
					else if(Math.abs(heading - HEADING_ERROR) <= 180){
						yDir = -1;
					}
					else if(Math.abs(heading - HEADING_ERROR) <= 270){
						xDir = -1;
					}
                //upload the current position that sensor read
				if(xDir != 0) {
					absAdjust = adj(xUpdateArr);
					
					updateArr[0] = adj(xUpdateArr) ;
					
					odometer.setPosition(updateArr, xUpdateArr);
				} else {
					absAdjust = adj(yUpdateArr);
		
					updateArr[1] = absAdjust;
					
					odometer.setPosition(updateArr, yUpdateArr);
				}
			}
			
			
			// this ensure the odometry correction occurs only once every period
			correctionEnd = System.currentTimeMillis();
			// this ensure the odometry correction occurs only once every period
			correctionEnd = System.currentTimeMillis();
			if (correctionEnd - correctionStart < CORRECTION_PERIOD) {
				try {
					Thread.sleep(CORRECTION_PERIOD
							- (correctionEnd - correctionStart));
				} catch (InterruptedException e) {
					// there is nothing to be done here because it is not
					// expected that the odometry correction will be
					// interrupted by another thread
				}
			}
		
		}
	}
	//the method is to correct value for x and y
	public static double adj (boolean [] update)
	{
		double newPosition = 0;
		double currentPosition;

		if (update[0])
		{
			currentPosition = odometer.getX();

			if (currentPosition <= 25 && currentPosition >= 0)
			{
				newPosition = 15;
			}

			else if (currentPosition> 25 && currentPosition <= 55)
			{
				newPosition = 45.48;
			}
			else if(currentPosition>55 &&currentPosition <= 90){
				newPosition = 76.06;
			}
			//work on x

		}

		else {
			//work on y
			currentPosition = odometer.getY();

			if (currentPosition <= 25 && currentPosition >= 0)
			{
				newPosition = 15;
			}

			else if (currentPosition> 25 && currentPosition <= 55)
			{
				newPosition = 45.48;
			}
			else if(currentPosition>55 &&currentPosition <= 90){
				newPosition = 76.06;
			}
		}

		return newPosition;

	}
	//the method is to update the current position for x and y
	public static double current (boolean [] update)
	{
		
		double currentPosition;

		if (update[0])
		{
			currentPosition = odometer.getX();

		}

		else {
			//work on y
			currentPosition = odometer.getY();

		}

		return currentPosition;

	}

}
