package ev3Odometer;

import lejos.hardware.ev3.LocalEV3;
import lejos.hardware.motor.EV3LargeRegulatedMotor;
import lejos.hardware.port.MotorPort;
import lejos.hardware.port.Port;

public class Robot {

	// Left motor connected to output A
	// Right motor connected to output D
	public static final EV3LargeRegulatedMotor leftMotor = new EV3LargeRegulatedMotor(LocalEV3.get().getPort("A"));
	public static final EV3LargeRegulatedMotor rightMotor = new EV3LargeRegulatedMotor(LocalEV3.get().getPort("D"));

	// Constants
	public double WHEEL_RADIUS = 2.1;
	public double TRACK = 16.1;
	
	// lock object for mutual exclusion
	private Object lock;

	public Robot(){
		lock = new Object();
	}

	public double getTrack() {
		double tempTrack;
		synchronized (lock) {
			tempTrack = TRACK;
		}
		return tempTrack;
	}

	public void setTrack(double tempTrack) {
		synchronized (lock) {
			TRACK = tempTrack;
		}
	}

	public double getWHEEL_RADIUS() {
		double tempWHEEL_RADIUS;
		synchronized (lock) {
			tempWHEEL_RADIUS = WHEEL_RADIUS;
		}
		return tempWHEEL_RADIUS;
	}

	public void setWHEEL_RADIUS(double tempWHEEL_RADIUS) {
		synchronized (lock) {
			WHEEL_RADIUS = tempWHEEL_RADIUS;
		}
	}
}
