package wallFollower;
import lejos.hardware.motor.*;

public class BangBangController implements UltrasonicController{
	private final int bandCenter, bandwidth;
	private final int motorLow, motorHigh;
	private int distance;
	private EV3LargeRegulatedMotor leftMotor, rightMotor;
	
	//	Values for filter method
	private final int FILTER_OUT = 30;	//100 & 200
	private int filterControl;
	
	//BendCenter to 25
	
	public BangBangController(EV3LargeRegulatedMotor leftMotor, EV3LargeRegulatedMotor rightMotor,
							  int bandCenter, int bandwidth, int motorLow, int motorHigh) {
		//Default Constructor
		this.bandCenter = bandCenter;
		this.bandwidth = bandwidth;
		this.motorLow = motorLow;
		this.motorHigh = motorHigh;
		this.leftMotor = leftMotor;
		this.rightMotor = rightMotor;
		/*leftMotor.setSpeed(motorHigh);				// Start robot moving forward
		rightMotor.setSpeed(motorHigh);
		leftMotor.forward();
		rightMotor.forward();*/
		
		//	value for filter
		filterControl = 0;
	}
	
	@Override
	public void processUSData(int distance) {
		// TODO: process a movement based on the us distance passed in (BANG-BANG style)
		
		//	filter from PController
		// rudimentary filter - toss out invalid samples corresponding to null
		// signal.
		// (n.b. this was not included in the Bang-bang controller, but easily
		// could have).
		//
		if (distance >= 50 && filterControl < FILTER_OUT) {
			// bad value, do not set the distance variable, however do increment the
			// filter value
			filterControl++;
		} else if (distance >= 50) {
			// We have repeated large values, so there must actually be nothing
			// there: leave the distance alone
			this.distance = distance;
		} else {
			// distance went below 255: reset filter and leave
			// distance alone.
			filterControl = 0;
			this.distance = distance;
		}
		
		//	Adjust the distance value due to the 45 degrees angle
		
		int horizontal = (int) (this.distance*0.707106781);
		int vertical = (int) (this.distance*0.707106781);
		
		//	The boundary values 
		
		int upperBound = this.bandCenter + this.bandwidth;
		int lowerBound = this.bandCenter - this.bandwidth;
			
		//	If it's too close to either side or front walls, turn right
		if(horizontal < lowerBound || vertical < lowerBound){
			this.rightMotor.setSpeed(motorLow);
			this.leftMotor.setSpeed(motorHigh);
			
			leftMotor.forward();
			rightMotor.forward();
		}
		
		//	IF it's too far from the side wall, including the convex corner thanks to the rudimentary filter
		else if(horizontal > upperBound){
			this.leftMotor.setSpeed(motorLow);
			this.rightMotor.setSpeed(motorHigh);
			
			leftMotor.forward();
			rightMotor.forward();
		}
		
		// If everything is within bounds
		else{
			this.leftMotor.setSpeed(motorHigh);
			this.rightMotor.setSpeed(motorHigh);
			
			leftMotor.forward();
			rightMotor.forward();
		}
		
	}

	@Override
	public int readUSDistance() {
		return this.distance;
	}
}
