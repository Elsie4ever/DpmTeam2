
package lab3TRY;

public class Odometer extends Thread {
	//robot position variables
	private double x, y, theta;
	private double distancePerDegreeRotationLeft;
	private double distancePerDegreeRotationRight;

	private int leftMotorTachoCount;
	private double distanceL;
	private int rightMotorTachoCount;
	private double distanceR;
	private double xNew;
	private double yNew;
	private double thetaNew;

	private double deltaT;
	private double deltaD;

	//update period for odometer(ms)
	private static final long ODOMETER_PERIOD = 25;

	private Object lock;

	//constructor
	public Odometer() {
		x = 0.0;
		y = 0.0;
		theta = 00.0;
		lock = new Object();
		distancePerDegreeRotationLeft = Math.PI * (Lab3.WHEEL_RADIUS_L) / 180.00;
		distancePerDegreeRotationRight = Math.PI * (Lab3.WHEEL_RADIUS_R) / 180.00;
	}

	//run
	public void run() {
		long updateStart, updateEnd;

		while (true) {
			updateStart = System.currentTimeMillis();

			// get tacho count at beginning
			// reset the tacho count for another loop to start
			leftMotorTachoCount = Lab3.leftMotor.getTachoCount();
			rightMotorTachoCount = Lab3.rightMotor.getTachoCount();
			Lab3.rightMotor.resetTachoCount();
			Lab3.leftMotor.resetTachoCount();

			synchronized (lock) {
				// don't use the variables x, y, or theta anywhere but here!

				//calculate left distance and right distance
				distanceL = distancePerDegreeRotationLeft * ((double) leftMotorTachoCount);
				distanceR = distancePerDegreeRotationRight * ((double) rightMotorTachoCount);

				//calculate the travel distance for robot
				deltaD = (distanceL + distanceR) / (2.0);
                //calculate radians turned by robot
				deltaT = (distanceL - distanceR) / Lab3.TRACK;
                //calculate x,y and theta
				xNew = x + (deltaD) * Math.sin(theta + (deltaT)/2.0); // Used sin for x because of definition of angle
				yNew = y + (deltaD) * Math.cos(theta + (deltaT)/2.0); // Used cos for y because of definition of angle
				thetaNew = theta + deltaT;

				//Save values
				x = xNew;
				y = yNew;
				theta = thetaNew;

				//upper bound
				if (theta > 6.28) {
					theta = theta - 6.28;
				}

				//lower bound
				if (theta < 0) {
					theta = 6.28 + theta;
				}


			}

			//ensure odometer runs once a period
			updateEnd = System.currentTimeMillis();
			if (updateEnd - updateStart < ODOMETER_PERIOD) {
				try {
					Thread.sleep(ODOMETER_PERIOD - (updateEnd - updateStart));
				} catch (InterruptedException e) {

				}
			}
		}
	}

	public void getPosition(double[] position, boolean[] update) {
		//synchronize with lock so values don't change while odometer is running
		synchronized (lock) {

			if (update[0])
				position[0] = x;
			if (update[1])
				position[1] = y;
			if (update[2])
				position[2] = theta;
		}
	}

    //get current position
	public double getX() {
		double result;

		synchronized (lock) {
			result = x;
		}

		return result;
	}

	public double getY() {
		double result;

		synchronized (lock) {
			result = y;
		}

		return result;
	}

	public double getTheta() {
		double result;

		synchronized (lock) {
			result = theta;
		}

		return result;
	}

//set current position
	public void setPosition(double[] position, boolean[] update) {
		// ensure that the values don't change while the odometer is running
		synchronized (lock) {
			if (update[0])
				x = position[0];
			if (update[1])
				y = position[1];
			if (update[2])
				theta = position[2];
		}
	}

	public void setX(double x) {
		synchronized (lock) {
			this.x = x;
		}
	}

	public void setY(double y) {
		synchronized (lock) {
			this.y = y;
		}
	}

	public void setTheta(double theta) {
		synchronized (lock) {
			this.theta = theta;
		}
	}
}