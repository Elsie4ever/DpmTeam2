package lab3TRY;

import lejos.hardware.ev3.LocalEV3;
import lejos.hardware.motor.EV3LargeRegulatedMotor;

public class ObstacleAvoidance extends Thread {

	/** enum controller: choose bangbang or p controller */
	enum Controller {BANGBANG, PCONT};
	private Controller chosenController = Controller.BANGBANG;
	//variables for BangBang Controller
	private static final int bandCenter1 = 38;			// Offset from the wall (cm)  
	private static final int bandWidth1 = 6;			// Width of dead band (cm)  
	private static final int motorLow1 = 100;			// Speed of slower wheel (deg/sec)
	private static final int motorHigh1 = 175;			// Speed of the faster wheel (deg/seec)
	//variables for P Controller
	int bandCenter2 = 40;  
	int bandwidth2 = 5;
	int motorStraight2 = 200;  

	//Constants
	private static final int FORWARD_SPEED = 100;
	private static final int ROTATE_SPEED = 80;

	//Variables of threads
	private Navigator navigator;
	private Odometer odometer;
	private UltrasonicPoller ultrasonicPoller;

	//Variables
	private EV3LargeRegulatedMotor ultrasonicSensorMotor;
	private EV3LargeRegulatedMotor leftMotor;
	private EV3LargeRegulatedMotor rightMotor;
	private Location finalPosition;
	private Location startingPosition;
	private double slope;
	boolean isSafe;

	//tolerances
	double tolSlope = 45;
	double tolFinalTheta = 0.40;

	//Constructor 
	public ObstacleAvoidance (Navigator navigator) {
		this.navigator = navigator;
		this.odometer = navigator.getOdometer();
		this.ultrasonicPoller = navigator.getUsPoller();
		this.finalPosition = navigator.getCurrentDestination();
		this.ultrasonicSensorMotor = Lab3.ultrasonicSensorMotor;
		this.leftMotor = Lab3.leftMotor;
		this.rightMotor = Lab3.rightMotor;
		this.isSafe = false;
	}

	@Override
	public void run() {

		//before obstacle avoidance begins.

		// Record the starte position for the wallfollower state and calculate the slope of the line joining the starting position and final position.
		startingPosition = navigator.getPositionFromOdometer();
		slope = (finalPosition.getY() - startingPosition.getY())/(finalPosition.getX() - startingPosition.getX());

		//Turn the ultrasonic sensor for detecting the obstacle
		ultrasonicSensorMotor.rotate(-45, false);    

		//When ultrasonic sensor detects an obstacle, move back a little bit
		leftMotor.setSpeed(ROTATE_SPEED);
		rightMotor.setSpeed(ROTATE_SPEED);
		leftMotor.rotate(-convertAngle(Lab3.WHEEL_RADIUS_L, Lab3.TRACK, 60), true);    // Return right away
		rightMotor.rotate(-convertAngle(Lab3.WHEEL_RADIUS_R, Lab3.TRACK, 60), false); // Return after the motion is complete

		//Rotate 90 degrees to the right.
		leftMotor.setSpeed(ROTATE_SPEED);
		rightMotor.setSpeed(ROTATE_SPEED);
		leftMotor.rotate(convertAngle(Lab3.WHEEL_RADIUS_L, Lab3.TRACK, 90), true);    // Return right away
		rightMotor.rotate(-convertAngle(Lab3.WHEEL_RADIUS_R, Lab3.TRACK, 90), false); // Return after the motion is complete

		//get starting angle.
		double startingTheta = odometer.getTheta();
		//Use startingTheta to calculate ideal termination angle
		double finalTheta    = startingTheta + Math.PI;
		//If the angle is greater than 360 degree, subtract it into 0-6.28 degree
		if (finalTheta > 2.0*Math.PI) finalTheta = finalTheta - 2.0*Math.PI;

		//begin to wallfollower state
		while (true) {

			//get distance
			int distance = ultrasonicPoller.getDistance();

			//odometer correction by choosing the different wallfollowing controller.
			switch (chosenController) {
			//if choosing bangbang controller
				case BANGBANG:
                     
					if ( Math.abs(distance - bandCenter1) < bandWidth1/2) {
						//robot going around the bandcenter, go straight
						leftMotor.setSpeed(motorLow1);
						leftMotor.forward();
						rightMotor.setSpeed(motorLow1);
						rightMotor.forward();
					}
					else if (distance < bandCenter1) {
						//when robot is too close, turn left.

						// make left motor speed higher
						leftMotor.setSpeed(motorHigh1);
						leftMotor.forward();

						// Remain the speed for right motor
						rightMotor.setSpeed(motorLow1);
						rightMotor.forward();
					}
					else if (distance > bandCenter1) {
						// If robot is too far, turn left

						// make right motor speed higher
						rightMotor.setSpeed(motorHigh1);
						rightMotor.forward();

						// Remain the speed for left motor
						leftMotor.setSpeed(motorLow1);
						leftMotor.forward();
					}
					else {
						//go straight when nothing is happened
						leftMotor.setSpeed(motorLow1);
						leftMotor.forward();
						rightMotor.setSpeed(motorLow1);
						rightMotor.forward();
					}

					break;
			    //if choosing bangbang controller
				case PCONT:
					if (distance > 51) distance = 51;

					//error between bandcenter and measured distance
					int error = bandCenter2 - distance;

					if (Math.abs(error) <= bandwidth2) {
						//robot going around the bandcenter, go straight
						leftMotor.forward();
						rightMotor.forward();

					} else if (error < 0 && error >= -20) {
						// If robot is too far, turn left
						leftMotor.setSpeed(50 + error);
						rightMotor.setSpeed(120 - error);
						leftMotor.forward();
						rightMotor.forward();
						leftMotor.setSpeed(motorStraight2);
						rightMotor.setSpeed(2 * motorStraight2);
						leftMotor.forward();
						rightMotor.forward();

					} else if (error > 0 && error <= 20) {
						// If robot is too close, turn right
						leftMotor.setSpeed(motorStraight2 + (2 * error));
						rightMotor.setSpeed(100 - (4 * error));
						leftMotor.forward();
						rightMotor.forward();

					} else if (error > 20) {

						leftMotor.setSpeed(motorStraight2);
						rightMotor.setSpeed(0);
						leftMotor.forward();
						rightMotor.forward();

					}
					break;
			}

			//get theta now
			double currentTheta = odometer.getTheta();
			if ((finalTheta - tolFinalTheta < currentTheta) && (currentTheta < tolFinalTheta + finalTheta)) {
				//turn sensor to forward position
				ultrasonicSensorMotor.rotate(45, false);
				//Set boolean to true, obstacle issue is resolved
				isSafe = true;
				return;
			}

			try {
				Thread.sleep(50);
			} catch (Exception e) {
			}
		}

	}

	public boolean isResolved() {
		return isSafe;//return boolean
	}

	public static int convertDistance(double radius, double distance) {
		return (int) ((180.0 * distance) / (Math.PI * radius));
	}

	public static int convertAngle(double radius, double width, double angle) {
		return convertDistance(radius, Math.PI * width * angle / 360.0);
	}

}
