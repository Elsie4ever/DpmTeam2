

package lab3TRY;

import lejos.hardware.motor.EV3LargeRegulatedMotor;
import lejos.internal.io.SystemSettings;

public class Navigator extends Thread {

	//Constants
	private static final int FORWARD_SPEED = 100;
	private static final int ROTATE_SPEED = 80;
	private static boolean[] getAllValues = {true, true, true};

	private Odometer odometer;
	private UltrasonicPoller usPoller;
	private boolean status;
	enum State {INIT, TURNING, TRAVELLING, EMERGENCY};

	//Variables of motors
	private EV3LargeRegulatedMotor leftMotor = Lab3.leftMotor;
	private EV3LargeRegulatedMotor rightMotor = Lab3.rightMotor;

	//Variables of positions 
	private Location currentDestination;
	private double destinationAngle;
	private double[] currentPosition = new double[3];

	//Tolerances
	private static double tolTheta = 0.04; 
	private static double tolEuclideanDistance = 5.0;
	private static int    tolClose = 15;

	// Constructor
	public Navigator(Odometer odometer, UltrasonicPoller usPoller) {
		this.odometer = odometer;
		this.usPoller = usPoller;
		this.status = false;
	}

	//return odometer
	public Odometer getOdometer() {
		return odometer;
	}

	//return ultrasonic poller.
	public UltrasonicPoller getUsPoller() {
		return usPoller;
	}

	//return current destination
	public Location getCurrentDestination() {
		return currentDestination;
	}

	public void travelTo (double x, double y) {
		//set destination.
		currentDestination = new Location(x, y);

		//set the angle required to destination.
		destinationAngle = getDestinationAngle();

		//set status to true.
		status = true;
	}

	//calculate the angle has to turned to the destination
	private double getDestinationAngle() {

		//get current position
		odometer.getPosition(currentPosition, getAllValues);
		double currentX = currentPosition[0];
		double currentY = currentPosition[1];

		//get current destination 
		double destinationX = currentDestination.getX();
		double destinationY = currentDestination.getY();

		//differences
		double deltaX = destinationX - currentX;
		double deltaY = destinationY - currentY;

		// Determine destination angle
		double angle = Math.atan2(deltaX, deltaY);

		if (angle < 0) {
			angle = 2.0*Math.PI + angle;
		}

		return angle;

	}

	//turn robot to destination minimal angle 
	private void turnTo (double destAngle) {

		//get the current angle and determine the heading error based on destAngle
		double currentAngle = odometer.getTheta();
		double headingError = destAngle - currentAngle;

		//ensure  the angle is minimal
		if (headingError < -Math.PI) {
			//if error is smaller than -180.
			headingError = headingError + 2*Math.PI;
		}
		else if (headingError > Math.PI) {
			//if error is bigger than +180.
			headingError = headingError - 2*Math.PI;
		}
		else {
			//if error is between -180 and 180
			//then it is minimum angle.
		}

		//after correcting angles, rotate the robot to desired angle
		leftMotor.setSpeed(ROTATE_SPEED);
		rightMotor.setSpeed(ROTATE_SPEED);
		if (headingError >= 0.0) {
			leftMotor.forward();
			rightMotor.backward();
		}
		else {
			leftMotor.backward();
			rightMotor.forward();
		}

	}

	//return true if robot is at proper angle 
	
	private boolean facingDestination (double destinationAngle) {
		double currentTheta = odometer.getTheta();
		return ((destinationAngle - tolTheta) < currentTheta) && (currentTheta < (destinationAngle + tolTheta));
	}

    //return current position of robot
	public Location getPositionFromOdometer () {
		odometer.getPosition(currentPosition, getAllValues);
		return new Location(currentPosition[0], currentPosition[1]);
	}

	//return true if at current destination within tolerance
	private boolean atDestination (Location currentLocation) {

		//calculate euclidean distance
		double distance = Math.sqrt(
				Math.pow(currentDestination.getX() - currentLocation.getX(), 2.0)
						+ Math.pow(currentDestination.getY() - currentLocation.getY(), 2.0)
			);

		return (distance < tolEuclideanDistance);
	}

	//ensure they are moving forward at FORWARD_SPEED.
	private void updateTravel () {
		// Ensure speeds are set to FORWARD_SPEED.
		leftMotor.setSpeed(FORWARD_SPEED);
		rightMotor.setSpeed(FORWARD_SPEED);
		// Ensure wheels are moving forward.
		leftMotor.forward();
		rightMotor.forward();
	}

	//return true if robot is navigating 
	public boolean isNavigating () {
		return status;
	}

    //return true if in emergency
	private boolean checkEmergency() {
		return usPoller.getDistance() < tolClose;
	}

	public static int convertDistance(double radius, double distance) {
		return (int) ((180.0 * distance) / (Math.PI * radius));
	}

	public static int convertAngle(double radius, double width, double angle) {
		return convertDistance(radius, Math.PI * width * angle / 360.0);
	}

	//run
	public void run() {

		State state = State.INIT;
		ObstacleAvoidance avoidance = new ObstacleAvoidance(this);

		while (true) {

			switch (state) {
			
				case INIT:
					if (status) {
						state = State.TURNING;
					}
					break;
			
				case TURNING:
					//returns only when the motion is complete
					turnTo(destinationAngle);
					//if the angle is correct, set state to TRAVELLING.
					if (facingDestination(destinationAngle)) {
						state = State.TRAVELLING;
					}
					break;
	
				case TRAVELLING:
					Location currentPosition = getPositionFromOdometer();
					if (checkEmergency()) {
						state = State.EMERGENCY;
						avoidance = new ObstacleAvoidance(this);
						avoidance.start();
					}
					else if (!atDestination(currentPosition)) {
						updateTravel();
					}
					else {
						leftMotor.stop();
						rightMotor.stop();
						//operation complete and set navigating status into false, then reset state to INIT
						status = false;
						state = State.INIT;
					}
					break;
				case EMERGENCY:
					if (avoidance.isResolved()) {
						state = State.TURNING;
						//reset destination angle 
						destinationAngle = getDestinationAngle();
					}
					break;
				default:
					leftMotor.stop();
					rightMotor.stop();
					break;
			}

			try {
				Thread.sleep(30);
			}
			catch (InterruptedException e) {
				e.printStackTrace();
			}

		}

	}

}