package lab3TRY;

/**
 * The object have the coordinate
 */
public class Location {

	private double x;
	private double y;

	public Location (double x, double y) {
		setX(x);
		setY(y);
	}
    //set x coordinate
	public void setX(double x) {
		this.x = x;
	}
    //get x coordinate
	public double getX() {
		return x;
	}
	//set y coordinate
	public void setY(double y) {
		this.y = y;
	}
	//get y coordinate
	public double getY() {
		return y;
	}
}
