

package lab3TRY;

import lejos.hardware.Button;
import lejos.hardware.ev3.LocalEV3;
import lejos.hardware.port.Port;
import lejos.hardware.lcd.TextLCD;
import lejos.hardware.motor.EV3LargeRegulatedMotor;
import lejos.hardware.sensor.EV3UltrasonicSensor;
import lejos.hardware.sensor.SensorModes;
import lejos.robotics.SampleProvider;

public class Lab3 {
	
	// State motors, textLCD informations
	private static final Port usPort = LocalEV3.get().getPort("S1");
	public static final EV3LargeRegulatedMotor leftMotor = new EV3LargeRegulatedMotor(LocalEV3.get().getPort("A"));
	public static final EV3LargeRegulatedMotor rightMotor = new EV3LargeRegulatedMotor(LocalEV3.get().getPort("D"));
	public static final EV3LargeRegulatedMotor ultrasonicSensorMotor = new EV3LargeRegulatedMotor(LocalEV3.get().getPort("B"));
	public static final TextLCD t = LocalEV3.get().getTextLCD();

	//State informations of robot
	public static final double WHEEL_RADIUS_L = 2.01; // radius of left wheel
	public static final double WHEEL_RADIUS_R = 2.01; // radius of right wheel
	public static final double TRACK = 14.45;          // The distance between two wheels
													

	public static void main(String[] args) throws InterruptedException {

		//clear the tachocount at beginning
		leftMotor.resetTachoCount();
		rightMotor.resetTachoCount();

		int buttonChoice;

		do {
			// clear display
			t.clear();

			//the option to do navigation or navigation with avoiding
	
			t.drawString("< Left | Right >", 0, 0);
			t.drawString("Navig- | Navig- ", 0, 1);
			t.drawString("ation  | ation  ", 0, 2);
			t.drawString("       |        ", 0, 3);
			t.drawString("Part 1 | Part 2 ", 0, 4);

			buttonChoice = Button.waitForAnyPress();
		} while (buttonChoice != Button.ID_LEFT //if left or right button are not pressed
				&& buttonChoice != Button.ID_RIGHT);

		//when left button is pressed
		if (buttonChoice == Button.ID_LEFT) {

			// detect the closing obstacle. It will keep the distances for the distance to obstacle in its distance variable.
			SensorModes usSensor = new EV3UltrasonicSensor(usPort);
			SampleProvider usDistance = usSensor.getMode("Distance");
			float[] usData = new float[usDistance.sampleSize()];
			UltrasonicPoller usPoller = new UltrasonicPoller(usDistance, usData);

			//state new odometer, odometryDisplay and navigator
			Odometer odometer = new Odometer();
			OdometryDisplay odometryDisplay = new OdometryDisplay(odometer,t);
			Navigator navigator = new Navigator(odometer, usPoller);
            //start
			odometer.start();
			odometryDisplay.start();
			usPoller.start();
			navigator.start();

			try {
				Thread.sleep(200);
			}
			catch (InterruptedException e) {
				e.printStackTrace();
			}
            //run the first mission: Navigation with odometer correction
			completeCourse(navigator);

		}
		//when right button pressed, run the navigation with avoiding obstacle
		else {
			// detect the closing obstacle. It will keep the distances for the distance to obstacle in its distance variable.
			SensorModes usSensor = new EV3UltrasonicSensor(usPort);
			SampleProvider usDistance = usSensor.getMode("Distance");
			float[] usData = new float[usDistance.sampleSize()];
			UltrasonicPoller usPoller = new UltrasonicPoller(usDistance, usData);

			//state new odometer, odometryDisplay and navigator
			Odometer odometer = new Odometer();
			OdometryDisplay odometryDisplay = new OdometryDisplay(odometer,t);
			Navigator navigator = new Navigator(odometer, usPoller);
			//start
			odometer.start();
			odometryDisplay.start();
			usPoller.start();
			navigator.start();

			try {
				Thread.sleep(200);
			}
			catch (InterruptedException e) {
				e.printStackTrace();
			}
			//run the second mission: Navigation with odometer correction and avoiding obstacle 
			completeCoursetwo(navigator);

		}
		
		while (Button.waitForAnyPress() != Button.ID_ESCAPE);
		System.exit(0);
	}

    //first mission
	private static void completeCourse(Navigator navigator) throws InterruptedException {
		double [][] waypoints = {
				{60.0 , 30.0},
				{30.0 , 30.0},
				{30.0 , 60.0},
				{60.0 , 00.0}
		};

		for(double[] point : waypoints) {
			navigator.travelTo(point[0], point[1]);
			while (navigator.isNavigating()) {
				Thread.sleep(500);
			}
		}
	}
    //second mission
	private static void completeCoursetwo(Navigator navigator) throws InterruptedException {
		double [][] waypoints = {
				{00.0 , 60.0},
				{60.0 , 00.0}
		};

		for(double[] point : waypoints) {
			navigator.travelTo(point[0], point[1]);
			while (navigator.isNavigating()) {
				Thread.sleep(500);
			}
		}
	}


}






















