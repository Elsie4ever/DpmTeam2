

package lab3TRY;

import lejos.hardware.lcd.TextLCD;

public class OdometryDisplay extends Thread {
	private static final long DISPLAY_PERIOD = 250;
	private Odometer odometer;
	private TextLCD t;

	//constructor
	public OdometryDisplay(Odometer odometer, TextLCD t) {
		this.odometer = odometer;
		this.t = t;
	}

	// run 
	public void run() {
		long displayStart, displayEnd;
		double[] position = new double[3];

		//clear display
		t.clear();

		while (true) {
			displayStart = System.currentTimeMillis();

			// clear informations
			t.drawString("X:              ", 0, 0);
			t.drawString("Y:              ", 0, 1);
			t.drawString("T:              ", 0, 2);

			//get odometry information
			odometer.getPosition(position, new boolean[] { true, true, true });

			//display 
			for (int i = 0; i < 3; i++) {
				t.drawString(doubleToString(position[i], 2), 3, i);
			}
            //catch error
			displayEnd = System.currentTimeMillis();
			if (displayEnd - displayStart < DISPLAY_PERIOD) {
				try {
					Thread.sleep(DISPLAY_PERIOD - (displayEnd - displayStart));
				} catch (InterruptedException e) {
			
				}
			}
		}
	}
	
	private static String doubleToString(double x, int places) {
		String result = "";
		String stack = "";
		long t;
		
		// put minus sign  
		if (x < 0.0)
			result += "-";
		
		// put leading 0
		if (-1.0 < x && x < 1.0)
			result += "0";
		else {
			t = (long)x;
			if (t < 0)
				t = -t;
			
			while (t > 0) {
				stack = Long.toString(t % 10) + stack;
				t /= 10;
			}
			
			result += stack;
		}
		
		// put the decimal 
		if (places > 0) {
			result += ".";
		
			// put decimal number correctly
			for (int i = 0; i < places; i++) {
				x = Math.abs(x);
				x = x - Math.floor(x);
				x *= 10.0;
				result += Long.toString((long)x);
			}
		}
		
		return result;
	}

}
