package objectSearch;

import lejos.hardware.Sound;
import lejos.hardware.lcd.TextLCD;

public class ObjectID extends Thread {
	private ColorPoller coPoller;
	private UltrasonicPoller usPoller;
	private TextLCD t;
	private static final int THRESHOLD = 60;
	private static final int DIST = 6; //4
	private static final double COLOR = 1.75; //10
	
	public ObjectID(ColorPoller coPoller, UltrasonicPoller usPoller, TextLCD t){ // Constructor
		this.coPoller = coPoller;
		this.usPoller = usPoller;
		this.t = t;
	}
	
	public void run(){
		t.clear(); // Clear the display
		
		while(true){
			t.drawString("                 ", 0, 5);
			t.drawString("           ", 0, 6);
			
			//Check if there's an object & that it's close enough
			if(detectObj() && withinDist()){
				t.drawString("Object Detected: ", 0, 5);
				//Check what kind of block it is
				if(idObj()){
					t.drawString("    Block", 1, 6); //Styrofoam block
					//Sound.beep();
				}
				else{
					t.drawString("Not Block", 1, 6);
					//Sound.beep();
					//Sound.beep();
				}
			}
			else if(detectObj()){
				t.drawString("Object Detected: ", 0, 5);
				t.drawString("Too Far", 1, 6);
			}
			
			try { Thread.sleep(50); } catch(Exception e){};
		}
	}
	
	public boolean detectObj(){
		
		/*
		 * Returns true if there's an object within it's line of sight
		 */
		
		boolean detected = false;
		
		if(UltrasonicPoller.getDist() <= THRESHOLD){
			detected = true;
		}
		
		return detected;
	}
	
	public boolean withinDist(){
		
		/*
		 * Returns true if the block is within the distance where colors are read correctly
		 */
		
		boolean within = false;
		
		if(UltrasonicPoller.getDist() < DIST){
			within = true;
		}
		
		return within;
	}
	
	public boolean idObj(){
		/*
		 * Returns true if it's a styrofoam block
		 */
		
		boolean styro = false;
		
		if(coPoller.getColor() < COLOR){
			styro = true;
		}
		
		return styro;
	}
}
