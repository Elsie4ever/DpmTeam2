package objectSearch;

import java.util.Arrays;

import lejos.hardware.Sound;
import lejos.robotics.SampleProvider;
import objectSearch.SimpleNavigation;

public class LightLocalizer {
	private Odometer odo;
	private SampleProvider colorSensor;
	private float[] colorData;
	private float[] colorArray = new float[3];
	private SimpleNavigation simNav;
	private UltrasonicPoller usPoller;
	private static final double BLACK_LINE = 0.35;
	private static final float TRAVEL_SPEED = 200;
	private static final double SQUARE_DIST = 30.48;
	private static final double OFFSET = 9.8;
	private static final double usOFFSET = 12.9;
	
	public LightLocalizer(Odometer odo, UltrasonicPoller usPoller, SampleProvider colorSensor, float[] colorData, SimpleNavigation simNav) {
		this.odo = odo;
		this.colorSensor = colorSensor;
		this.colorData = colorData;
		this.simNav = simNav;
		this.usPoller = usPoller;
	}
	
	public void doLocalization() {
		/*
		double angleX1 = 0;
		double angleX2 = 0;
		double angleY1 = 0;
		double angleY2 = 0;
		*/
		double distX, distY;
		
		// drive to location listed in tutorial
		simNav.turnTo(180);
		distY = UltrasonicPoller.getDist() + usOFFSET;
		simNav.turnTo(270);
		distX = UltrasonicPoller.getDist() + usOFFSET;
		
		simNav.turnTo(45);
		simNav.travelTo(odo.getX() + (SQUARE_DIST - distX), odo.getY() + (SQUARE_DIST - distY));
		simNav.stopMov();
		
		odo.setX(0);
		odo.setY(0);
		simNav.turnTo(0);
		simNav.stopMov();
	}
}
