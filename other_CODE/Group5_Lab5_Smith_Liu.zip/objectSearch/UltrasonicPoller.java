package objectSearch;
import java.util.Arrays;

import lejos.robotics.SampleProvider;

//
//  Control of the wall follower is applied periodically by the 
//  UltrasonicPoller thread.  The while loop at the bottom executes
//  in a loop.  Assuming that the us.fetchSample, and cont.processUSData
//  methods operate in about 20mS, and that the thread sleeps for
//  50 mS at the end of each loop, then one cycle through the loop
//  is approximately 70 mS.  This corresponds to a sampling rate
//  of 1/70mS or about 14 Hz.
//


public class UltrasonicPoller extends Thread{
	private SampleProvider us;
	private float[] usData;
	private static double[] window = {0,0,0,0,0};
	private static Object lock = new Object();
	private static final int THRESHOLD = 80;
	
	private double distance;
	//private static final int THRESHOLD = 50;
	
	public UltrasonicPoller(SampleProvider us, float[] usData) {
		this.us = us;
		this.usData = usData;
	}

//  Sensors now return floats using a uniform protocol.
//  Need to convert US result to an integer [0,255]
	
	public void run() {
		while (true) {
			us.fetchSample(usData,0);							// acquire data
			filter((usData[0]*100.0));						// extract from buffer, cast to int
			windowFilter(this.distance);
			try { Thread.sleep(50); } catch(Exception e){}		// Poor man's timed sampling
		}
	}
	
	/*public int getDist(){
		return this.distance;
	}*/
	
	public void filter(double distance){
		if (distance >= THRESHOLD) {
			// We have repeated large values, so there must actually be nothing
			// there: leave the distance alone
			this.distance = THRESHOLD;
		} else {
			// distance went below 255: reset filter and leave
			// distance alone.
			this.distance = distance;
		}
	}
	
	public static double getDist(){
		synchronized(lock){
			double [] clone = clone(window);
			Arrays.sort(clone);
			return clone[clone.length/2];
		}
	}
	
	private static double [] clone (double[] original){
		synchronized(lock){
			double [] clone = new double[original.length];
			
			for(int i = 0; i < original.length; i++){
				clone[i] = original[i];
			}
			
			return clone;
		}
	}
	
	private static void windowFilter(double distance){
		synchronized(lock){
			shift(window);
			window[window.length - 1] = distance;
		}
	}
	
	private static void shift(double[] window){
		synchronized(lock){
			for(int i = 0; i < window.length - 1; i++){
				window[i] = window[i + 1];
			}
		}
	}
}
