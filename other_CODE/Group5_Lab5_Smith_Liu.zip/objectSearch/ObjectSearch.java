package objectSearch;

import java.util.ArrayList;

import lejos.hardware.Sound;
import lejos.hardware.motor.EV3LargeRegulatedMotor;
import objectSearch.ObjectID;
import objectSearch.UltrasonicPoller;
import objectSearch.SimpleNavigation;
import objectSearch.Odometer;

public class ObjectSearch extends Thread{
	private ObjectID objID;
	private ArrayList<Double> coord = new ArrayList<Double>();
	private UltrasonicPoller usPoller;
	private SimpleNavigation simNav;
	private SimpleNavigation simNavF;
	private Odometer odo;
	private static final int DIST = 6;
	private boolean detected = false;
	private EV3LargeRegulatedMotor leftClaw;
	private EV3LargeRegulatedMotor rightClaw;
	private static final int DIST_CLAW1 = 8;
	private static final int DIST_CLAW2 = 4;
	
	public ObjectSearch(ObjectID objID, UltrasonicPoller usPoller, SimpleNavigation simNav,
			SimpleNavigation simNavF, Odometer odo,
			EV3LargeRegulatedMotor leftClaw, EV3LargeRegulatedMotor rightClaw){ //Constructor
		this.objID = objID;
		this.usPoller = usPoller;
		this.simNav = simNav;
		this.simNav = simNavF;
		this.odo = odo;
		this.leftClaw = leftClaw;
		this.rightClaw = rightClaw;
	}
	
	public void run(){
		//1. Check for any obstacles
		//2. Check color of each obstacles (beep once if styro, twice if not)
		//3. Push the styrofoam to upper-right corner (beep three times)
		
		//Search for the block
		//Case 1: blocks apart
		Search();
		
		//Case 2: styrofoam was behind block <- better if obstacle avoidance
		if(!detected){
			//Upper-Left Corner
			simNav.travelTo(0, 30.48*2);
			simNav.turnTo(90);
			Search();
			
			//Upper-Right Corner
			simNav.travelTo(30.48*2, 30.48*3);
			simNav.turnTo(180);
			Search();
			
			//Lower-Right Corner
			simNav.travelTo(30.48*3, 0);
			simNav.turnTo(270);
			Search();
		}
		
		//Capture the block
		if(detected){
			Capture();
		}
		
		//Go to point of delivery
		simNav.travelTo(30.48*2, 30.48*2);
		Sound.beep();
		Sound.beep();
		Sound.beep();
	}
	
	public void Search(){
		//Your robot then uses its sensors to search for objects on the floor.
		//When it encounters an object it should beep once if the object is the Styrofoam block and twice otherwise.
		//If the object  is  not  the  Styrofoam  block,  it  should  move  away  from  the  object  and  continue searching.
		double startHead = odo.getTheta();
		if(startHead < Math.toRadians(3) || startHead > Math.toRadians(357)){
			startHead = 0;
		}
		
		double endHead = (startHead + Math.PI/2)%(2*Math.PI);
		
		simNav.turnCW();
		while(odo.getTheta() < endHead){ // Detect all blocks
			simNav.turnCW();
			if(objID.detectObj()){ //Note down the coordinates of that block
				if(odo.getTheta()*180/Math.PI <= 10){
					try { Thread.sleep(1000); } catch(Exception e){}
				}
				else if(odo.getTheta()*180/Math.PI <= 45 && odo.getTheta()*180/Math.PI > 10){
					try { Thread.sleep(600); } catch(Exception e){}
				}
				else if(odo.getTheta()*180/Math.PI <= 50 && odo.getTheta()*180/Math.PI > 45){
					try { Thread.sleep(1000); } catch(Exception e){}
				}
				
				else if(odo.getTheta()*180/Math.PI <= 80 && odo.getTheta()*180/Math.PI > 50){
					try { Thread.sleep(1000); } catch(Exception e){}
				}
				else{
					try { Thread.sleep(1750); } catch(Exception e){}
				}
				
				simNav.stopMov();
				Sound.beepSequenceUp();
				double curTheta = SimpleNavigation.mathToCompass(odo.getTheta()*180/Math.PI)*Math.PI/180;
				double distance = UltrasonicPoller.getDist() - DIST;
				coord.add(distance*Math.cos(curTheta));
				coord.add(distance*Math.sin(curTheta));
				simNav.turnCW();
				
				try { Thread.sleep(2000); } catch(Exception e){} // To not catch the same block again
				// If within theta = dont check again
			}
		}
		
		simNav.stopMov();
		
	
		for(int i = 0; i < coord.size(); i += 2){
			simNav.travelTo(coord.get(i), coord.get(i+1));
			simNav.stopMov();
			
			/*sweep();
			Sound.beepSequenceUp();
			simNav.stopMov();*/
			
			//Get closer if needed
			while(!objID.withinDist()){
				simNav.forward();
			}
			simNav.stopMov();
			
			detected = objID.idObj();
			if(!detected){
				Sound.beep();
				simNav.backward();
				try { Thread.sleep(1000); } catch(Exception e){}; // To back away from the wrong block
			}
			else if(detected){
				Sound.beep();
				Sound.beep();
				break;
			}
		}
	}
	
	public void Search2(){
		//Your robot then uses its sensors to search for objects on the floor.
		//When it encounters an object it should beep once if the object is the Styrofoam block and twice otherwise.
		//If the object  is  not  the  Styrofoam  block,  it  should  move  away  from  the  object  and  continue searching.
		double startHead = odo.getTheta();
		if(startHead < Math.toRadians(3) || startHead > Math.toRadians(357)){
			startHead = 0;
		}
		
		double endHead = (startHead + Math.PI/2)%(2*Math.PI);
		
		simNav.turnCW();
		while(odo.getTheta() < endHead){ // Detect all blocks
			simNav.turnCW();
			if(objID.detectObj()){ //Note down the coordinates of that block
				Sound.beepSequenceUp();
				
				double blockHead = odo.getTheta();
				double blockHeadDist = UltrasonicPoller.getDist() - DIST;
				double blockEnd = odo.getTheta();
				double blockEndDist = UltrasonicPoller.getDist() - DIST;
				while(objID.detectObj()){
					blockEnd = odo.getTheta();
					blockEndDist = UltrasonicPoller.getDist() - DIST;
				}
				Sound.beepSequence();
				double blockX = (blockHeadDist*Math.cos(blockHead) + blockEndDist*Math.cos(blockEnd))/2;
				double blockY = (blockHeadDist*Math.sin(blockHead) + blockEndDist*Math.sin(blockEnd))/2;
				coord.add(blockX);
				coord.add(blockY);
			}
		}
		
		simNav.stopMov();
		
	
		for(int i = 0; i < coord.size(); i += 2){
			simNav.travelTo(coord.get(i), coord.get(i+1));
			simNav.stopMov();
			
			sweep();
			Sound.beepSequenceUp();
			simNav.stopMov();
			
			//Get closer if needed
			while(!objID.withinDist()){
				simNav.forward();
			}
			simNav.stopMov();
			
			detected = objID.idObj();
			if(!detected){
				Sound.beep();
				simNav.backward();
				try { Thread.sleep(1000); } catch(Exception e){}; // To back away from the wrong block
			}
			else if(detected){
				Sound.beep();
				Sound.beep();
				break;
			}
		}
	}
	
	public void sweep(){
		simNav.turnTo((((odo.getTheta() - Math.PI)*180/Math.PI)+2*Math.PI)%(2*Math.PI));
		
		double minDist = UltrasonicPoller.getDist();
		simNav.turnCW();
		boolean turn = true;
		boolean foundMin = false;
		while(turn){
			double curDist = UltrasonicPoller.getDist();
			if(!foundMin){
				simNav.turnCW();
			}
			else if(curDist < minDist){
				minDist = curDist;
				foundMin = true;
				simNav.turnCW();
			}
			else{
				simNav.stopMov();
				turn = false;
			}
		}
	}
	
	public void Capture(){
		//If a Styrofoam block is detected, your robot should push it to the upper right hand corner
		//of the floor section, beep 3 times when the move is completed, and then stop.
		
		do{
			simNav.backward();
		}
		while(UltrasonicPoller.getDist() < DIST_CLAW1);
		simNav.stopMov();
		claw1();
		
		simNav.forward();
		try { Thread.sleep(500); } catch(Exception e){};
		//while(UltrasonicPoller.getDist() < DIST_CLAW2);
		simNav.stopMov();
		claw2();
		
	}
	
	public void claw1(){
		leftClaw.rotate(120, true);
		rightClaw.rotate(120);
	}
	
	public void claw2(){
		leftClaw.rotate(45, true);
		rightClaw.rotate(45);
	}
}
