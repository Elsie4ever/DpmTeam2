package wallFollower;
import lejos.hardware.motor.*;

public class BangBangController implements UltrasonicController{
	private final int bandCenter, bandwidth;
	private final int motorLow, motorConstant, motorHigh;
	private final int FILTER_OUT = 50; //setting cap
	private int distance;
	private EV3LargeRegulatedMotor leftMotor, rightMotor, usMotor;
	private int filterControl;

	
	public BangBangController(EV3LargeRegulatedMotor leftMotor, EV3LargeRegulatedMotor rightMotor, EV3LargeRegulatedMotor usMotor,
							  int bandCenter, int bandwidth, int motorLow, int motorHigh, int motorConstant) {
		//Default Constructor
		this.bandCenter = bandCenter;
		this.bandwidth = bandwidth;
		this.motorLow = motorLow;
		this.motorConstant = motorConstant; //construct constant speed
		this.motorHigh = motorHigh;
		this.leftMotor = leftMotor;
		this.rightMotor = rightMotor;
		this.usMotor = usMotor; //construct usMotor
		leftMotor.setSpeed(motorConstant);				// Start robot moving forward
		rightMotor.setSpeed(motorConstant);
		usMotor.rotateTo(0); // gives the motor an initial value/the sensor an initial direction
		leftMotor.forward();
		rightMotor.forward(); //uses the initial speed to begin the path
		filterControl = 0;
	}
	
	@Override
	public void processUSData(int distance, boolean usForward) {
		this.distance = distance;
		// TODO: process a movement based on the us distance passed in (BANG-BANG style)
		//BANG-BANG style means that the speed/angle of the turn is a constant (either on or off)
		
		//Bang Bang Filter
		// rudimentary filter - toss out invalid samples corresponding to null signal.
				// (n.b. this was not included in the Bang-bang controller, but easily could have).
				//
				if (distance > bandwidth + 2*bandCenter && filterControl < FILTER_OUT) {
					// bad value, do not set the distance var, however do increment the filter value
					filterControl++;
				} else if (distance > bandwidth + bandCenter){
					// true greater than range, therefore set distance to detected distance
					this.distance = distance;
				} else {
					// distance went below range, therefore reset everything.
					filterControl = 0;
					this.distance = distance;
				}
				
		
		
		//if US sensor is pointing forwards
		if(usForward){
			//if it's too close to the wall to be able to handle a right turn without hitting it
			//Ideally, it would never back up because it would never be that close to a wall
			if(distance < 14){
				rightMotor.setSpeed(motorConstant);
				leftMotor.setSpeed(motorConstant);
				rightMotor.backward();
				leftMotor.backward();
			}
			
			//if approaching a wall, turn right (robot follows wall on its left)
			//chose bandCenter plus a constant in order to start the right turn earlier than +bandwidth as right turns are slower than left turns
			else if(distance <= bandCenter + 8){ 
				//note: if it sees a wall, it stops reading left until it completes its turn (UltrasonicPoller.java)
				rightMotor.setSpeed(0); //set at 0 for a more abrupt right turn
				rightMotor.forward();
				leftMotor.forward();
				}
			else{
				rightMotor.forward();
				leftMotor.forward();
			}
		}		
		//END OF if US sensor is pointing forwards
		
		
		//if US sensor is pointing left
		/*if(!usForward){
			//if it's too far to the right or no wall, turn left. 
			//2 is an adjustment number for left turns.
			if(distance > bandCenter + bandwidth - 2){
				//The for loop adds extra filter time so it does not turn left too much
				for(int i = 0; i < 50; i++){
					rightMotor.setSpeed(motorConstant);
					rightMotor.forward(); 
					}
				//now set speed at high to turn left					
				rightMotor.setSpeed(motorHigh - 50);
				leftMotor.setSpeed(motorConstant - 40);
			}
			
			//if its too close to the left, turn right
			//minus less than the bandwidth for the above because right turns are slow and canceling full bandwidth adds a little extra buffer
			if(distance <= bandCenter - 5){
				rightMotor.setSpeed(motorLow);
				leftMotor.setSpeed(motorConstant);
			}
			//otherwise, let it go straight
			if((distance >= bandCenter - 5)&& (distance <= bandCenter + bandwidth - 2)){	
				rightMotor.setSpeed(motorConstant);
				leftMotor.setSpeed(motorConstant);
			}
			//move motors now that the speed is set
			rightMotor.forward();
			leftMotor.forward(); //this is in case the motor was going backwards when looking in front
		}*/
		if(!usForward){
			//safety mechanism, so it stops turning left if it sees a wall too close to the left
			if(distance < 15){
				rightMotor.setSpeed(motorConstant + 50);
				leftMotor.setSpeed(motorConstant);
				rightMotor.backward();
				leftMotor.backward();
			}
			//if it's too far to the right or no wall, turn left. 
			//2 is an adjustment number for left turns.
			else if(distance > bandCenter + bandwidth - 2){
				//The for loop adds extra filter time so it does not turn left too much
				for(int i = 0; i < 50; i++){
					rightMotor.setSpeed(motorConstant);
					rightMotor.forward(); 
					}
				//now set speed at high to turn left					
				rightMotor.setSpeed(motorHigh - 50);
				leftMotor.setSpeed(motorConstant - 40);
				rightMotor.forward();
				leftMotor.forward();
			}
			
			//if its too close to the left, turn right
			//minus less than the bandwidth for the above because right turns are slow and canceling full bandwidth adds a little extra buffer
			else if(distance <= bandCenter - 5){
				rightMotor.setSpeed(motorLow);
				leftMotor.setSpeed(motorConstant);
				rightMotor.forward();
				leftMotor.forward();
			}
			//otherwise, let it go straight
			else if((distance >= bandCenter - 5)&& (distance <= bandCenter + bandwidth - 2)){	
				rightMotor.setSpeed(motorConstant);
				leftMotor.setSpeed(motorConstant);
				rightMotor.forward();
				leftMotor.forward();
			}
		}
		//END OF if US sensor is pointing left
			
		
	}

	@Override
	public int readUSDistance() {
		return this.distance;
	}
}
