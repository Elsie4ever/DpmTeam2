package wallFollower;
import lejos.hardware.motor.*;

public class PController implements UltrasonicController {
	
	private final int bandCenter, bandwidth;
	private final int motorStraight = 250, FILTER_OUT = 20;
	private EV3LargeRegulatedMotor leftMotor, rightMotor, usMotor;
	private int distance;
	private int filterControl;
	private int p; //proportion constant
	
	public PController(EV3LargeRegulatedMotor leftMotor, EV3LargeRegulatedMotor rightMotor, EV3LargeRegulatedMotor usMotor,
					   int bandCenter, int bandwidth, int motorConstant) {
		//Default Constructor
		this.bandCenter = bandCenter;
		this.bandwidth = bandwidth;
		this.leftMotor = leftMotor;
		this.rightMotor = rightMotor;
		this.usMotor = usMotor;
		leftMotor.setSpeed(motorStraight);					// Initialize motor rolling forward
		rightMotor.setSpeed(motorStraight);
		leftMotor.forward();
		rightMotor.forward();
		filterControl = 2;
		p = 13;
	}
	
	@Override
	public void processUSData(int distance, boolean usForward) {
		
		// rudimentary filter - toss out invalid samples corresponding to null signal.
		// (n.b. this was not included in the Bang-bang controller, but easily could have).
		//
		if (distance > bandwidth + 2*bandCenter && filterControl < FILTER_OUT) {
			// bad value, do not set the distance var, however do increment the filter value
			filterControl++;
		} else if (distance > bandwidth + bandCenter){
			// true greater than range, therefore set distance to detected distance
			this.distance = distance;
		} else {
			// distance went below 255, therefore reset everything.
			filterControl = 0;
			this.distance = distance;
		}
		
		// TODO: process a movement based on the us distance passed in (P style)	
		//P style means that the speed/angle of turn is proportional to the distance away from the wall
		//the output of a proportional controller is the multiplication product of the error 
		//signal and the proportional gain
		
		//if US sensor is pointing left
		if(!usForward){
			if (distance > 150) // if the sensor doesn't pick up on any objects nearby
				distance = 150; // default the distance to 150 so we don't overcompensate with a higher value on the p controller
			
			if(distance > bandCenter+3 ) {//if it's a little too far to the right, turn in left.
				
				rightMotor.setSpeed(motorStraight+p*(Math.abs(distance-bandCenter-bandwidth))); //speeds up the right motor to turn left
			}
				
			

			if(distance <= bandCenter-3) //if its a little too close to the left, turn out right slightly
				rightMotor.setSpeed(motorStraight-p*(Math.abs(bandCenter+bandwidth-distance))); // slows the right motor to turn right
	
			if((distance < bandCenter+3)&&(distance > bandCenter-3)){ // if its +/- 3 from the bandCenter, just set the robot straight instead of using a p controller speed
				rightMotor.setSpeed(motorStraight); //applies normal straight speed
				leftMotor.setSpeed(motorStraight);
			}

			leftMotor.forward(); //apply the changes to the speeds
			rightMotor.forward(); //^
		}
		
		
		
		//when US sensor is pointing forward
		if (usForward){
			
			if(distance < 11){
				rightMotor.setSpeed(motorStraight);
				rightMotor.backward(); // sets speeds backwards  so the robot gets a little extra space to work with
				leftMotor.backward();
			}
			
			
			else if(distance < bandCenter) //if it's getting close to a wall, turn right a little
				rightMotor.setSpeed(motorStraight-4*p*(Math.abs((bandCenter-distance)))); // adjust the speed setting so it can hone in on the bandCenter
			if(distance >= 15){ // if it isn't going backwards, we go forwards
				leftMotor.forward(); // apply forward speed
				rightMotor.forward();
			}
		}
	}
	

	
	@Override
	public int readUSDistance() {
		return this.distance; //gets distance from other class
	}

}