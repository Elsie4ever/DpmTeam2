package wallFollower;

public interface UltrasonicController {
	
	public void processUSData(int distance, boolean usForward);
	
	public int readUSDistance();
}
