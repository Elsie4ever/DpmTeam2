package wallFollower;
import lejos.robotics.SampleProvider;
import lejos.hardware.motor.*;

//
//  Control of the wall follower is applied periodically by the 
//  UltrasonicPoller thread.  The while loop at the bottom executes
//  in a loop.  Assuming that the us.fetchSample, and cont.processUSData
//  methods operate in about 20mS, and that the thread sleeps for
//  50 mS at the end of each loop, then one cycle through the loop
//  is approximately 70 mS.  This corresponds to a sampling rate
//  of 1/70mS or about 14 Hz.
//


public class UltrasonicPoller extends Thread{
	private SampleProvider us;
	private UltrasonicController cont;
	private float[] usData;
	private EV3LargeRegulatedMotor usMotor; //create US motor
	private boolean usForward; //create boolean in USPoller

	
	public UltrasonicPoller(SampleProvider us, float[] usData, UltrasonicController cont, EV3LargeRegulatedMotor usMotor) {
		this.us = us;
		this.cont = cont;
		this.usData = usData;
		this.usMotor = usMotor;
		
	}

//  Sensors now return floats using a uniform protocol.
//  Need to convert US result to an integer [0,255]
	
	public void run() {
		int distance;
		usForward = true;
		while (true) {
			if(!usForward){
				us.fetchSample(usData,0);							// acquire data
				distance =(int)(usData[0]*100.0);					// extract from buffer, cast to int
				cont.processUSData(distance, usForward);						// now take action depending on value
				try { Thread.sleep(35);  } catch(Exception e){}		// Poor man's timed sampling
				if(distance > 42){ //if US sees nothing to its left
					usForward = false; //then it stops looking forward, so it knows when to stop turning 
									//when constantly looking left (it will stop turning when it detects a wall).
				}
				else{
					usForward = true; //if there is no wall to the left, then proceed as usually expected (turn forward)
					usMotor.rotateTo(0); //point US forward
				}
			}
			else if(usForward){
				us.fetchSample(usData,0);							// acquire data
				distance =(int)(usData[0]*100.0);					// extract from buffer, cast to int
				cont.processUSData(distance, usForward);						// now take action depending on value
				try { Thread.sleep(35);  } catch(Exception e){}		// Poor man's timed sampling
				if(distance < 35){		//if the distance is within the bandcenter and bandwidth, then only look forward, stop looking left
					usForward = true;
					//usMotor stays at 0, else if is entered again
				}
				else{					//or else, it stops looking forward as usually expected
					usForward = false;
					usMotor.rotateTo(-90); //point US to the left
				}
			}
			//testing if statements when US is pointing left
			/*usMotor.rotateTo(-90);								//US pointing left
			us.fetchSample(usData,0);							// acquire data
			distance =(int)(usData[0]*100.0);					// extract from buffer, cast to int
			cont.processUSData(distance, usForward);						// now take action depending on value
			try { Thread.sleep(20);  } catch(Exception e){}*/
		}
	}

}
