package lab;

import lejos.hardware.Sound;
import lejos.robotics.SampleProvider;
import lejos.utility.Delay;

public class USLocalizer {
	public enum LocalizationType {
		FALLING_EDGE, RISING_EDGE
	};

	public static int ROTATION_SPEED = 30;

	private Odometer odo;
	private SampleProvider usSensor;
	private float[] usData;
	private LocalizationType locType;
	private int delay = 40;
	private Navigation navi;
	private int errorFilter, errorFilterMax, distanceMax, wallDistance;

	public USLocalizer(Odometer odo, SampleProvider usSensor, float[] usData, LocalizationType locType) {
		this.odo = odo;
		this.usSensor = usSensor;
		this.usData = usData;
		this.locType = locType;
		navi = new Navigation(odo);
		errorFilter = 0;
		errorFilterMax = 70;
		distanceMax = 70;
		wallDistance = 30;
	}

	public void doLocalization() {
		double[] pos = new double[3];
		double angleA, angleB;

		if (locType == LocalizationType.FALLING_EDGE) {

			// rotate the robot until it sees no wall
			double currentDistance = this.getFilteredData();

			while (currentDistance <= wallDistance) {				//if current distance is less than 30cm, still sees wall, rotate the robot until it sees no wall
																		
				navi.setSpeeds(ROTATION_SPEED, -ROTATION_SPEED);	
				Delay.msDelay(delay);										
				currentDistance = this.getFilteredData();
			}

			// keep rotating until the robot sees a wall, then latch the angle

			while (currentDistance > wallDistance) {					//if the distance is greater than 30 cm, sees no wall
																		//keep rotating until the robot sees a wall
				navi.setSpeeds(ROTATION_SPEED, -ROTATION_SPEED);			
				Delay.msDelay(delay);										
				currentDistance = this.getFilteredData();
			}
			angleA = odo.getAng();										//latch angleA
            Sound.beep();
	

			
			while (currentDistance <= wallDistance) {					//if current distance is less than 30cm again,
																		//then rotate in the opposite direction, until sees no wall

				navi.setSpeeds(-ROTATION_SPEED, ROTATION_SPEED);			
				Delay.msDelay(delay);
				Delay.msDelay(3000);
				currentDistance = this.getFilteredData();
			}

			
			while (currentDistance > wallDistance) {					//if the distance is greater than 30 cm, sees no wall
																		//then  keep rotating until sees wall again
																		
				navi.setSpeeds(-ROTATION_SPEED, ROTATION_SPEED);			
				Delay.msDelay(delay);										
				currentDistance = this.getFilteredData();
			}
			angleB = odo.getAng();										//latch angleB
			Sound.beep();
			// angleA is clockwise from angleB, so assume the average of the
			// angles to the right of angleB is 45 degrees past 'north'

			odo.getLeftMotor().stop(true);				//stop the robot from turning to get more accurate reading
			odo.getRightMotor().stop(false);

			double deltaDegree; 
			deltaDegree = (360+angleB+45-(((360+angleB-angleA)%360)/2))%360-90;	//calculate the deltadegree ev3 should turn to the correct postion
			navi.turnTo(deltaDegree, true);										//rotate that degree
			
			// update the odometer position 
			odo.setPosition(new double[] { 0.0, 0.0, 0.0 }, new boolean[] { true, true, true }); //reset position to all zeros
			
			
			Delay.msDelay(4000);					//delay 4000ms
			
			 
		} else {
			/*
			 * The robot should turn until it sees the wall, then look for the
			 * "rising edges:" the points where it no longer sees the wall. This
			 * is very similar to the FALLING_EDGE routine, but the robot will
			 * face toward the wall for most of it.
			 */

			double currentDistance = this.getFilteredData();
			while (currentDistance > wallDistance) {		//if the distance is greater than 30 cm, sees no wall
				                                            //keep rotating until the robot sees a wall
				navi.setSpeeds(ROTATION_SPEED, -ROTATION_SPEED);			
				Delay.msDelay(delay);										
				currentDistance = this.getFilteredData();

			}

			// keep rotating until the robot sees no wall, then latch the angle

			while (currentDistance <= wallDistance) {		//if current distance is less than 30cm, still sees wall, rotate the robot until it sees no wall
				navi.setSpeeds(ROTATION_SPEED, -ROTATION_SPEED);			
				Delay.msDelay(delay);										
				currentDistance = this.getFilteredData();

			}
			angleA = odo.getAng();	//latch angleA

			
			
			//keep rotating
			while (currentDistance > wallDistance) {		//if the distance is greater than 30 cm, sees no wall
				                                             //then keep rotating in poopsite direction until sees wall again
				
				navi.setSpeeds(-ROTATION_SPEED, ROTATION_SPEED);			
				Delay.msDelay(delay);										
				currentDistance = this.getFilteredData();

			}

			// keep rotating until the robot sees no wall, then latch the angle
			while (currentDistance <= wallDistance) {		//if current distance is less than 30cm again,
				                                            //then keep rotating until sees no wall
				navi.setSpeeds(-ROTATION_SPEED, ROTATION_SPEED);			
				Delay.msDelay(delay);										
				currentDistance = this.getFilteredData();

			}
			angleB = odo.getAng();							//latch angleB

			// angleB is clockwise from angleA, so assume the average of the
			// angles to the right of angleA is 45 degrees past 'north'

			odo.getLeftMotor().stop(true);
			odo.getRightMotor().stop(false);				//stop the robot

			double deltaDegree;

			deltaDegree = (360+angleA+45-(((360+angleA-angleB)%360)/2))%360;		//calculate the deltadegree ev3 should turn to the correct postion
			navi.turnTo(deltaDegree, true);										    //rotate that degree

			// update the odometer position (example to follow:)
			
			Delay.msDelay(4000);  				//delay 4000 ms
			
			odo.setPosition(new double[] { 0.0, 0.0, 0.0 }, new boolean[] { true, true, true }); 	//reset position to all zeros
		}
	}
	
	private float getFilteredData() {
		usSensor.fetchSample(usData, 0);					//get distance value from ultronic sensor to  usData
		if (usData[0] * 100 > distanceMax && errorFilter < errorFilterMax) {	//if sensor distance is larger than 70, there may be something wrong, the filter starts to count  
			errorFilter++;                                                        // to see if this is a real distance or just wrong reading
			return (distanceMax-1);
		} else if (usData[0] * 100 > distanceMax && errorFilter >= errorFilterMax) {	// if it counts more than 70 times, its a real distance
			return usData[0] * 100;
		} else {
			float distance = usData[0] * 100;

			if (distance > distanceMax) {					// if the sensor distance is greater than maxdistance 70, set it to 70
				distance = distanceMax;
			}
			if (distance == 0) {							//if the sensor distance is zero, set it to previous value
				return usData[1] * 100;
			}
			errorFilter = 0;								
			return distance;
		}
	}

}
