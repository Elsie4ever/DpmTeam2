package lab;

/*
 * File: Navigation.java
 * Written by: Sean Lawlor
 * ECSE 211 - Design Principles and Methods, Head TA
 * Fall 2011
 * Ported to EV3 by: Francois Ouellet Delorme
 * Fall 2015
 * 
 * Movement control class (turnTo, travelTo, flt, localize)
 */
import lejos.hardware.motor.EV3LargeRegulatedMotor;

public class Navigation {
	final static int FAST = 200, SLOW = 100, ACCELERATION = 1100, TURNSPEED = 50; //acceleration 400 original //1100
	final static double DEG_ERR = 1.0, CM_ERR = 1.0, radius = 2.1; //deg err// 3.0
	private Odometer odometer;
	private EV3LargeRegulatedMotor leftMotor, rightMotor;

	public Navigation(Odometer odo) {
		this.odometer = odo;

		EV3LargeRegulatedMotor[] motors = this.odometer.getMotors();
		this.leftMotor = motors[0];
		this.rightMotor = motors[1];

		// set acceleration
		this.leftMotor.setAcceleration(ACCELERATION);
		this.rightMotor.setAcceleration(ACCELERATION);
	}

	/*
	 * Functions to set the motor speeds jointly
	 */
	public void setSpeeds(float lSpd, float rSpd) {
		this.leftMotor.setSpeed(lSpd);
		this.rightMotor.setSpeed(rSpd);
		if (lSpd < 0)
			this.leftMotor.backward();
		else
			this.leftMotor.forward();
		if (rSpd < 0)
			this.rightMotor.backward();
		else
			this.rightMotor.forward();
	}

	public void setSpeeds(int lSpd, int rSpd) {
		this.leftMotor.setSpeed(lSpd);
		this.rightMotor.setSpeed(rSpd);
		if (lSpd < 0)
			this.leftMotor.backward();
		else
			this.leftMotor.forward();
		if (rSpd < 0)
			this.rightMotor.backward();
		else
			this.rightMotor.forward();
	}

	/*
	 * Float the two motors jointly
	 */
	public void setFloat() {
		this.leftMotor.stop();
		this.rightMotor.stop();
		this.leftMotor.flt(true);
		this.rightMotor.flt(true);
	}

	/*
	 * TravelTo function which takes as arguments the x and y position in cm
	 * Will travel to designated position, while constantly updating it's
	 * heading
	 */

	//the travelTo that comes with this package is not properly performed 
	
	
//change something on travelto
	public void travelTo(double xfinal, double yfinal) {
		double x=this.odometer.getX(); 
		double y=this.odometer.getY();//get current position
		double deltaX = xfinal - x; 
		double deltaY = yfinal - y; // different distance between taget and current position
		
		double newDeg, distance;

		newDeg = calculateNewDegree(xfinal,yfinal,deltaX,deltaY); //change theta to absolute value to turn (calculation method)
		this.turnTo(newDeg*180.0/Math.PI, true);				//turn to this radius
																
		distance = Math.sqrt(deltaX*deltaX + deltaY*deltaY); //absolute distance from final pos.

		leftMotor.setSpeed(SLOW);
		rightMotor.setSpeed(SLOW); //rotate in low speed
		leftMotor.rotate(convertDistance(radius, distance), true);  // convert the distance to travel to the angle the mortor should rotate
		rightMotor.rotate(convertDistance(radius, distance), false); 
		}

	/*
	 * TurnTo function which takes an angle and boolean as arguments The boolean
	 * controls whether or not to stop the motors when the turn is completed
	 */

	public void turnTo(double angle, boolean stop) {

		double error = angle - this.odometer.getAng();

		while (Math.abs(error) > DEG_ERR) {

			error = angle - this.odometer.getAng();

			if (error < -180.0) {
				this.setSpeeds(-TURNSPEED, TURNSPEED);
			} else if (error < 0.0) {
				this.setSpeeds(TURNSPEED, -TURNSPEED);
			} else if (error > 180.0) {
				this.setSpeeds(TURNSPEED, -TURNSPEED);
			} else {
				this.setSpeeds(-TURNSPEED, TURNSPEED);
			}
		}

		if (stop) {
			this.setSpeeds(0, 0);
		}
	}

	public int convertAngle(double radius, double width, double angle) { // converts rotations of robot to
		return convertDistance(radius, Math.PI * width * angle / (2 * Math.PI)); // the required angle rotation of
																					// the wheel
	}

	public int convertDistance(double radius, double distance) { // converts
																	// distance
																	// to angle
		return (int) ((180.0 * distance) / (Math.PI * radius));
	}
	
	/* Based on current and final positions, what is the absolute angle of the final position*/
	public double calculateNewDegree(double x, double y, double dx, double dy){ 
		if (dx >= 0) {
			if (dy >= 0) {
				return Math.atan(Math.abs(dx) / Math.abs(dy));
			} else {
				return Math.PI/2 + Math.atan(Math.abs(dy) / Math.abs(dx));
			}
		} else {
			if (dy >= 0) {
				return Math.PI*3/2 + Math.atan(Math.abs(dy) / Math.abs(dx));
			} else {
				return Math.PI + Math.atan(Math.abs(dx) / Math.abs(dy));
			}
		}
	}

	/*
	 * Go foward a set distance in cm
	 */
	public void goForward(double distance) {
		this.travelTo(Math.cos(Math.toRadians(this.odometer.getAng())) * distance,
				Math.cos(Math.toRadians(this.odometer.getAng())) * distance);

	}
}
