package lab;
import lejos.hardware.Sound;
import lejos.hardware.motor.EV3LargeRegulatedMotor;
import lejos.robotics.SampleProvider;

public class LightLocalizer {
	private Odometer odo;
	private SampleProvider colorSensor;
	private float[] colorData;	
	private double d=11;	//by measurement, the distance between ls and the center of track  //distance between lighr sensor and left wheel
	private double x,y,theta; //new values 
	private EV3LargeRegulatedMotor leftMotor, rightMotor;
	
	public static final double WHEEL_RADIUS = 2.1;		//wheel radius
	public static final double TRACK = 15.7;			//distance between two wheels in cm


	public static double ROTATION_SPEED = 50;	//set rotation speed to 50
	public static double forwardspeed=100;	    // set forward speed t o100
	private static final int sleepperiod=200;	//i frist have this value like 10 or something
	
	//later by testing i found its better leave it 0 thus no sleeping time 
	
	public LightLocalizer(Odometer odo, SampleProvider colorSensor, float[] colorData) 
	{
		this.odo = odo;
		this.colorSensor = colorSensor;
		this.colorData = colorData;
		this.leftMotor = this.odo.getLeftMotor();
		this.rightMotor = this.odo.getRightMotor();      //get data from odometer
	}
	
	public void doLocalization() {
		double [] pos = new double [3];//setup a new array "pos" to store the value from odometer
		Navigation navi=new Navigation(this.odo);//to use this method in navigation
		
		navi.turnTo(45,true);	//after finish us localizer, we are at 0 degree, x-axis, and we turn 45 degree counterclockwise to start part 2
		odo.setPosition(new double [] {0.0, 0.0, 45}, new boolean [] {false, false, true}); // set our position at 0 (x-axis) 0 (y-axis) and 45 degree
		
		leftMotor.setSpeed((int)forwardspeed);
		rightMotor.setSpeed((int)forwardspeed);
		leftMotor.rotate(convertDistance(WHEEL_RADIUS,22),true);   // as we are at (0,0), turn ev3 to 0 degree
		rightMotor.rotate(convertDistance(WHEEL_RADIUS,22),false);  // right motor can start rotation at the same time as left motor
		//next step can start as long as right motor finish rotate
		leftMotor.stop();    //right motor and right motor stop
		rightMotor.stop();
		
		
		
		
		double angle[]=new double[4];	//set up a new array to stor angle values 
		int countgridlines=0;	//counter to count black lines (increment)
		while (countgridlines<=3) //the light sensor should detect 4 black gridlines 
		{	
			colorSensor.fetchSample(colorData,0);      		//get value from light sensor  (red mode)
			int LSvalue=  (int)((colorData[0])*100);	   //the value from light sensor is very small (below 1), so we times this value by 100, it would be easier to see if we meet the gridlines 
			//when the value get from light sensor is above 68 (approximately), there is no gridlines.
			pos=odo.getPosition();	//get current posistion 
			if (LSvalue<=50)	 //when the value get from light sensor below 50, it means ev3 see a gridline  (we set it to 50 as it can stop ev3 quicker
			
			{
				Sound.twoBeeps();  //beep two times
				angle[countgridlines]=pos[2];	//stores that angle to the angle array one by one
				countgridlines++;	//counter counts (increment)
				if (countgridlines==4)	//if ev3 found all four gridlines, motors stop, and exit this loop
				{
					leftMotor.stop();
					rightMotor.stop(); //stop
					
					Sound.beep(); //beep
					break; 
				}
			} 
			leftMotor.setSpeed((int) ROTATION_SPEED); 
			rightMotor.setSpeed((int) ROTATION_SPEED);
			leftMotor.backward();
			rightMotor.forward();                //rotate ev3 to left
			try { Thread.sleep(sleepperiod); } catch(Exception e){}	
		}
		
		
		
		
		
		double temp=0; 
		
		temp=(360-angle[1]+angle[3])%360;
		y=-d*Math.cos(Math.PI*temp/360); //calculate current y postion
		temp=(360-angle[0]+angle[2])%360;
		x=-d*Math.cos(Math.PI*temp/360); //calculate current x postion
		theta=(angle[0]+190)+(((360 + angle[2] - angle[0])%360)/2);
		pos=odo.getPosition(); //get position from odometer
		theta=theta+pos[2];
		if (theta>=360)
		{
			theta=theta % 360; //if theta is greater than 360, it rotate the second laps, use mod to get actural angle
		}
		if (theta<0)
		{	
			theta=360+theta;
		}
		//calculate the difference distance between current position and (0,0) taget position and theta (angle need to retate to 0 degree)
		odo.setPosition(new double [] {x, y, 0}, new boolean [] {true, true, false});	
		Sound.buzz();
		navi.travelTo(0,0);
		navi.turnTo(theta, true);
		leftMotor.stop();
		rightMotor.stop();
		odo.setPosition(new double [] {x, y, 0}, new boolean [] {false,false,true});  //travel to (0,0) and turn to 0 degree
		}
	
	private static int convertAngle(double radius, double width, double angle) {
		return convertDistance(radius, Math.PI * width * angle / 360.0);
	}
	//calculate angle and distance
	private static int convertDistance(double radius, double distance) {
		return (int) ((180.0 * distance) / (Math.PI * radius));
	}
}
